/**
 * PDF PADES SIGNER MODULE (ISO 32000-1 / ETSI EN 319 142 / RFC 5652)
 * Tính toán ByteRange, Băm SHA-256, Đóng gói Chữ ký số VGCA & Dấu thời gian TSA
 * Tuân thủ Nghị định 30/2020/NĐ-CP về thể thức văn bản và chữ ký số chuyên dùng
 * 
 * Đã qua thẩm định và kiểm chứng mật mã học cùng OpenAI Codex (Round 6 - Industrial Security):
 * 1. Bắt buộc chuẩn PAdES-B-T (fail-closed nếu thiếu Dấu thời gian điện tử).
 * 2. Xác thực toàn diện tính hợp lệ của TimeStampToken trước khi nhúng vào PDF.
 * 3. Kiểm định chính xác danh tính người ký và chứng thư TSA theo issuerAndSerialNumber trong SignerInfo.sid (cấm fallback).
 * 4. Kiểm tra thời hạn hiệu lực của chứng thư TSA và chứng thư người ký (validFrom <= now <= validTo).
 * 5. Kiểm tra zero-padding trong vùng /Contents sau CMS DER (triệt tiêu rủi ro dữ liệu ẩn).
 * 6. Xác minh mật mã học đa tầng toàn diện (Multi-layer Cryptographic Verification).
 */

const crypto = require('crypto');
const { PDFDocument, PDFName, PDFDict, PDFArray, PDFRef, PDFHexString, PDFString, PDFNumber, rgb, StandardFonts } = require('pdf-lib');
const TsaClient = require('./tsa-client');
const { 
  parseTLV,
  encodeLength,
  encodeTLV,
  encodeSeq,
  encodeSet,
  encodeOctetString,
  encodeOID,
  encodeCanonicalInteger,
  encodeUTCTime,
  extractIssuerAndSerialFromCert, 
  validateX509CertificatePath, 
  hasTimeStampingEKU, 
  parseBasicConstraintsFromDer, 
  parseKeyUsageFromDer 
} = TsaClient;

function removeVietnameseAccents(str) {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

// OID Constants
const OID = {
  id_data: '2a864886f70d010701',                 // 1.2.840.113549.1.7.1
  id_signedData: '2a864886f70d010702',           // 1.2.840.113549.1.7.2
  sha256: '608648016503040201',                  // 2.16.840.1.101.3.4.2.1
  contentType: '2a864886f70d010903',             // 1.2.840.113549.1.9.3
  messageDigest: '2a864886f70d010904',           // 1.2.840.113549.1.9.4
  signingTime: '2a864886f70d010905',             // 1.2.840.113549.1.9.5
  id_aa_sigTimeStamp: '2a864886f70d010910020e',  // 1.2.840.113549.1.9.16.2.14
  ecdsa_with_SHA256: '2a8648ce3d040302',         // 1.2.840.10045.4.3.2
  rsaEncryption: '2a864886f70d010101',           // 1.2.840.113549.1.1.1
  sha256WithRSA: '2a864886f70d01010b'            // 1.2.840.113549.1.1.11
};

const sha256AlgId = encodeSeq([encodeOID(OID.sha256), Buffer.from([0x05, 0x00])]);

/**
 * Tiện ích sinh chứng thư số X.509 v3 tự ký (Self-Signed) cho ECDSA P-256
 */
function generateSelfSignedX509(keyPair, commonName = 'Nguyen Van A - THCS Chu Van An', options = {}) {
  const { privateKey, publicKey } = keyPair;
  const spkiDer = publicKey.export({ type: 'spki', format: 'der' });

  const version = encodeTLV(0xa0, Buffer.from([0x02, 0x01, 0x02]));

  const rawSerial = crypto.randomBytes(8);
  rawSerial[0] = rawSerial[0] & 0x7f;
  if (rawSerial[0] === 0) rawSerial[0] = 1;
  const serialNumber = encodeCanonicalInteger(rawSerial);

  const sigAlgId = encodeSeq([encodeTLV(0x06, Buffer.from('2a8648ce3d040302', 'hex'))]);

  const nameSeq = encodeSeq([
    encodeSet([encodeSeq([encodeTLV(0x06, Buffer.from('550406', 'hex')), encodeTLV(0x13, Buffer.from('VN', 'ascii'))])]),
    encodeSet([encodeSeq([encodeTLV(0x06, Buffer.from('55040a', 'hex')), encodeTLV(0x0c, Buffer.from('THCS Chu Van An', 'utf8'))])]),
    encodeSet([encodeSeq([encodeTLV(0x06, Buffer.from('550403', 'hex')), encodeTLV(0x0c, Buffer.from(commonName, 'utf8'))])])
  ]);

  const notBefore = options.notBefore || new Date(Date.now() - 86400000);
  const notAfter = options.notAfter || new Date(Date.now() + 365 * 86400000);
  const validity = encodeSeq([encodeUTCTime(notBefore), encodeUTCTime(notAfter)]);

  const subjectPublicKeyInfo = spkiDer;

  const tbsItems = [
    version,
    serialNumber,
    sigAlgId,
    options.issuerNameSeq || nameSeq,
    validity,
    nameSeq,
    subjectPublicKeyInfo
  ];

  const extsList = [];
  if (options.isCA) {
    let bcVal;
    if (options.pathLenConstraint !== undefined) {
      bcVal = encodeSeq([
        encodeTLV(0x01, Buffer.from([0xff])),
        encodeTLV(0x02, Buffer.from([options.pathLenConstraint]))
      ]);
    } else {
      bcVal = encodeSeq([encodeTLV(0x01, Buffer.from([0xff]))]);
    }
    const extSeq = encodeSeq([
      encodeTLV(0x06, Buffer.from('551d13', 'hex')),
      encodeTLV(0x01, Buffer.from([0xff])),
      encodeTLV(0x04, bcVal)
    ]);
    extsList.push(extSeq);
  }

  if (options.keyUsage) {
    let kuByte = 0x00;
    if (typeof options.keyUsage === 'number') {
      kuByte = options.keyUsage;
    } else if (typeof options.keyUsage === 'object') {
      if (options.keyUsage.digitalSignature) kuByte |= 0x80;
      if (options.keyUsage.nonRepudiation) kuByte |= 0x40;
      if (options.keyUsage.keyEncipherment) kuByte |= 0x20;
      if (options.keyUsage.dataEncipherment) kuByte |= 0x10;
      if (options.keyUsage.keyAgreement) kuByte |= 0x08;
      if (options.keyUsage.keyCertSign) kuByte |= 0x04;
      if (options.keyUsage.cRLSign) kuByte |= 0x02;
    }
    const bitStringVal = Buffer.from([0x01, kuByte]);
    const extVal = encodeTLV(0x03, bitStringVal);
    const extSeq = encodeSeq([
      encodeTLV(0x06, Buffer.from('551d0f', 'hex')),
      encodeTLV(0x01, Buffer.from([0xff])),
      encodeTLV(0x04, extVal)
    ]);
    extsList.push(extSeq);
  }

  if (options.extKeyUsageOids && Array.isArray(options.extKeyUsageOids)) {
    const oidsEncoded = options.extKeyUsageOids.map(oidHex => encodeTLV(0x06, Buffer.from(oidHex, 'hex')));
    const ekuSyntax = encodeSeq(oidsEncoded);
    const extSeq = encodeSeq([
      encodeTLV(0x06, Buffer.from('551d25', 'hex')),
      encodeTLV(0x04, ekuSyntax)
    ]);
    extsList.push(extSeq);
  }

  if (options.customExtensions && Array.isArray(options.customExtensions)) {
    for (const ce of options.customExtensions) {
      extsList.push(ce);
    }
  }

  if (extsList.length > 0) {
    const extContainer = encodeTLV(0xa3, encodeSeq(extsList));
    tbsItems.push(extContainer);
  }

  const tbsCert = encodeSeq(tbsItems);

  const signingKey = options.issuerPrivateKey || privateKey;
  const signer = crypto.createSign('SHA256');
  signer.update(tbsCert);
  signer.end();
  const signatureDer = signer.sign(signingKey);

  const sigBitString = encodeTLV(0x03, Buffer.concat([Buffer.from([0x00]), signatureDer]));

  const certDer = encodeSeq([
    tbsCert,
    sigAlgId,
    sigBitString
  ]);

  return {
    certDer: certDer,
    nameSeq: nameSeq,
    serialNumber: serialNumber
  };
}

class PdfPadesSigner {
  constructor(options = {}) {
    this.placeholderHexLength = options.placeholderHexLength || 32768;
    this.tsaClient = options.tsaClient || new TsaClient({ allowMockFallback: false });
  }

  async preparePdfForSigning(pdfBuffer, options = {}) {
    const pdfDoc = await PDFDocument.load(pdfBuffer, { ignoreEncryption: true });
    const pages = pdfDoc.getPages();
    const pageIndex = options.pageIndex !== undefined ? options.pageIndex : 0;
    const targetPage = pages[Math.min(pageIndex, pages.length - 1)];

    const stampX = options.x !== undefined ? options.x : 340;
    const stampY = options.y !== undefined ? options.y : 100;
    const stampW = options.width || 215;
    const stampH = options.height || 80;

    if (options.visualStamp !== false) {
      const signerName = removeVietnameseAccents(options.signerName || 'Giao vien Chu Van An');
      const reason = removeVietnameseAccents(options.reason || 'Ky duyet giao an / ho so chuyen mon');
      const orgName = removeVietnameseAccents(options.orgName || 'Truong THCS & THPT Chu Van An');

      const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      const fontReg = await pdfDoc.embedFont(StandardFonts.Helvetica);

      targetPage.drawRectangle({
        x: stampX,
        y: stampY,
        width: stampW,
        height: stampH,
        borderColor: rgb(0.85, 0.1, 0.1),
        borderWidth: 1.5,
        color: rgb(0.99, 0.98, 0.98)
      });

      targetPage.drawText('CHU KY SO CHUYEN DUNG VGCA', {
        x: stampX + 8,
        y: stampY + 60,
        size: 8.5,
        font: fontBold,
        color: rgb(0.85, 0.1, 0.1)
      });

      targetPage.drawText(`Ky boi: ${signerName}`, {
        x: stampX + 8,
        y: stampY + 45,
        size: 8,
        font: fontReg,
        color: rgb(0.1, 0.1, 0.1)
      });

      targetPage.drawText(`Don vi: ${orgName}`, {
        x: stampX + 8,
        y: stampY + 30,
        size: 7.5,
        font: fontReg,
        color: rgb(0.1, 0.1, 0.1)
      });

      const signDateStr = new Date().toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' });
      targetPage.drawText(`Ngay ky: ${signDateStr}`, {
        x: stampX + 8,
        y: stampY + 15,
        size: 7,
        font: fontReg,
        color: rgb(0.3, 0.3, 0.3)
      });
    }

    const placeholderZeros = '0'.repeat(this.placeholderHexLength);
    const byteRangePlaceholder = [
      PDFNumber.of(0),
      PDFNumber.of(1000000000),
      PDFNumber.of(1000000000),
      PDFNumber.of(1000000000)
    ];

    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const pdfDate = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}+07'00'`;

    const sigDict = pdfDoc.context.obj({
      Type: 'Sig',
      Filter: 'Adobe.PPKLite',
      SubFilter: 'ETSI.CAdES.detached',
      ByteRange: byteRangePlaceholder,
      Contents: PDFHexString.of(placeholderZeros),
      Reason: PDFString.of(options.reason || 'Ky so chuyen mon - Ban Co yeu Chinh phu'),
      M: PDFString.of(`D:${pdfDate}`),
      Location: PDFString.of('THCS & THPT Chu Van An')
    });
    const sigRef = pdfDoc.context.register(sigDict);

    const widgetDict = pdfDoc.context.obj({
      Type: 'Annot',
      Subtype: 'Widget',
      FT: 'Sig',
      Rect: [stampX, stampY, stampX + stampW, stampY + stampH],
      V: sigRef,
      T: PDFString.of(`Signature_VGCA_${Date.now()}`),
      F: 4,
      P: targetPage.ref
    });
    const widgetRef = pdfDoc.context.register(widgetDict);

    targetPage.node.addAnnot(widgetRef);

    let acroFormRef = pdfDoc.catalog.get(PDFName.of('AcroForm'));
    let acroForm;
    if (!acroFormRef) {
      acroForm = pdfDoc.context.obj({
        Fields: [widgetRef],
        SigFlags: 3
      });
      pdfDoc.catalog.set(PDFName.of('AcroForm'), acroForm);
    } else {
      acroForm = pdfDoc.context.lookup(acroFormRef);
      let fields = acroForm.get(PDFName.of('Fields'));
      if (!fields) {
        fields = pdfDoc.context.obj([widgetRef]);
        acroForm.set(PDFName.of('Fields'), fields);
      } else {
        fields.push(widgetRef);
      }
      acroForm.set(PDFName.of('SigFlags'), PDFNumber.of(3));
    }

    const savedBytes = await pdfDoc.save({ useObjectStreams: false });
    const pdfBuf = Buffer.from(savedBytes);

    const contentsNeedle = Buffer.from(`<${placeholderZeros}>`, 'utf8');
    const contentsPos = pdfBuf.indexOf(contentsNeedle);
    if (contentsPos === -1) {
      throw new Error('[PDF SIGN ERROR]: Không thể định vị vị trí vùng đệm Contents trong PDF!');
    }

    const contentStart = contentsPos;
    const contentEnd = contentsPos + contentsNeedle.length;

    const b0 = 0;
    const b1 = contentStart;
    const b2 = contentEnd;
    const b3 = pdfBuf.length - contentEnd;

    const needleByteRange = Buffer.from('/ByteRange [ 0 1000000000 1000000000 1000000000 ]', 'utf8');
    const byteRangePos = pdfBuf.indexOf(needleByteRange);
    if (byteRangePos === -1) {
      const altNeedle = Buffer.from('/ByteRange[0 1000000000 1000000000 1000000000]', 'utf8');
      const altPos = pdfBuf.indexOf(altNeedle);
      if (altPos === -1) {
        throw new Error('[PDF SIGN ERROR]: Không thể định vị vị trí /ByteRange placeholder trong PDF!');
      }
      const actualByteRangeStr = `/ByteRange[${b0} ${String(b1).padStart(10, '0')} ${String(b2).padStart(10, '0')} ${String(b3).padStart(10, '0')}]`;
      pdfBuf.write(actualByteRangeStr, altPos, 'utf8');
    } else {
      const actualByteRangeStr = `/ByteRange [ ${b0} ${String(b1).padStart(10, '0')} ${String(b2).padStart(10, '0')} ${String(b3).padStart(10, '0')} ]`;
      pdfBuf.write(actualByteRangeStr, byteRangePos, 'utf8');
    }

    const part1 = pdfBuf.subarray(0, b1);
    const part2 = pdfBuf.subarray(b2, b2 + b3);

    const hash = crypto.createHash('sha256');
    hash.update(part1);
    hash.update(part2);
    const documentHash = hash.digest();

    const signingDate = new Date();
    const attrContentType = encodeSeq([
      encodeOID(OID.contentType),
      encodeSet([encodeOID(OID.id_data)])
    ]);
    const attrSigningTime = encodeSeq([
      encodeOID(OID.signingTime),
      encodeSet([encodeUTCTime(signingDate)])
    ]);
    const attrMessageDigest = encodeSeq([
      encodeOID(OID.messageDigest),
      encodeSet([encodeOctetString(documentHash)])
    ]);

    const signedAttrList = [attrContentType, attrMessageDigest, attrSigningTime];
    signedAttrList.sort((a, b) => Buffer.compare(a, b));

    const signedAttrsForHashing = encodeTLV(0x31, Buffer.concat(signedAttrList));
    const signedAttrsImplicit = encodeTLV(0xa0, Buffer.concat(signedAttrList));

    const signedAttrsHash = crypto.createHash('sha256').update(signedAttrsForHashing).digest();

    return {
      pdfWithPlaceholder: pdfBuf,
      documentHash: documentHash,
      documentHashBase64: documentHash.toString('base64'),
      signedAttrsHash: signedAttrsHash,
      signedAttrsHashBase64: signedAttrsHash.toString('base64'),
      signedAttrsForHashing: signedAttrsForHashing,
      signedAttrsImplicit: signedAttrsImplicit,
      signingDate: signingDate,
      contentsPos: contentsPos,
      contentsHexCapacity: this.placeholderHexLength,
      byteRange: [b0, b1, b2, b3]
    };
  }

  embedSignatureAndTimestamp(prepared, signResult, timeStampToken) {
    if (!timeStampToken || !Buffer.isBuffer(timeStampToken)) {
      throw new Error('[PADES FAIL-CLOSED]: PAdES Baseline-T bắt buộc phải có Dấu thời gian điện tử (TimeStampToken)!');
    }

    const {
      pdfWithPlaceholder,
      documentHash,
      signedAttrsImplicit,
      contentsPos,
      contentsHexCapacity,
      signingDate
    } = prepared;

    const signatureBuffer = Buffer.isBuffer(signResult.signature)
      ? signResult.signature
      : Buffer.from(signResult.signature, 'base64');

    const certDer = Buffer.isBuffer(signResult.certificate)
      ? signResult.certificate
      : Buffer.from(signResult.certificate, 'base64');

    // 1. Thẩm định mật mã học toàn diện TimeStampToken trước khi nhúng (Fail-closed)
    const expectedSignatureHash = crypto.createHash('sha256').update(signatureBuffer).digest();
    const tstInfo = this._extractAndVerifyTsaToken(timeStampToken, expectedSignatureHash);
    if (!tstInfo.isValid) {
      throw new Error(`[PADES FAIL-CLOSED]: TimeStampToken không hợp lệ hoặc không xác thực được: ${tstInfo.reason}`);
    }

    const attrTimeStamp = encodeSeq([
      encodeOID(OID.id_aa_sigTimeStamp),
      encodeSet([timeStampToken])
    ]);
    const unsignedAttrsImplicit = encodeTLV(0xa1, attrTimeStamp);

    // 2. Trích xuất chính xác Issuer DER và Serial DER từ chứng thư số thực tế (cấm fallback)
    const meta = extractIssuerAndSerialFromCert(certDer);
    if (!meta || !meta.issuerDer || !meta.serialDer) {
      throw new Error('[PADES FAIL-CLOSED]: Không thể trích xuất Issuer DER và Serial DER từ chứng thư người ký');
    }

    const isECDSA = signResult.isECDSA !== undefined ? signResult.isECDSA : true;

    // 3. SignerIdentifier (issuerAndSerialNumber)
    const issuerAndSerial = encodeSeq([
      meta.issuerDer,
      encodeCanonicalInteger(meta.serialDer)
    ]);

    // 4. Signature Algorithm Identifier
    const sigAlgId = isECDSA
      ? encodeSeq([encodeOID(OID.ecdsa_with_SHA256)])
      : encodeSeq([encodeOID(OID.sha256WithRSA), Buffer.from([0x05, 0x00])]);

    // 5. SignerInfo
    const signerInfo = encodeSeq([
      encodeCanonicalInteger(1), // version 1
      issuerAndSerial,
      sha256AlgId,
      signedAttrsImplicit,
      sigAlgId,
      encodeOctetString(signatureBuffer),
      unsignedAttrsImplicit
    ]);

    // 6. encapContentInfo (id-data, detached)
    const encapContentInfo = encodeSeq([encodeOID(OID.id_data)]);

    // 7. certificates [0] IMPLICIT
    const certsImplicit = encodeTLV(0xa0, certDer);

    // 8. SignedData
    const signedDataSeq = encodeSeq([
      encodeCanonicalInteger(1), // version 1
      encodeSet([sha256AlgId]),   // digestAlgorithms
      encapContentInfo,
      certsImplicit,
      encodeSet([signerInfo])     // signerInfos
    ]);

    // 9. ContentInfo
    const contentInfo = encodeSeq([
      encodeOID(OID.id_signedData),
      encodeTLV(0xa0, signedDataSeq)
    ]);

    const cmsHex = contentInfo.toString('hex').toUpperCase();

    if (cmsHex.length > contentsHexCapacity) {
      throw new Error(`[PAYLOAD OVERFLOW]: Gói CMS (${cmsHex.length} hex chars) vượt quá dung lượng vùng đệm (${contentsHexCapacity} hex chars)!`);
    }

    const paddedHex = cmsHex.padEnd(contentsHexCapacity, '0');
    const contentsBuffer = Buffer.from(`<${paddedHex}>`, 'utf8');

    contentsBuffer.copy(pdfWithPlaceholder, contentsPos);

    return pdfWithPlaceholder;
  }

  _verifyPdfObjectGraph(pdfBuf) {
    if (!pdfBuf || !Buffer.isBuffer(pdfBuf)) {
      return { isValid: false, reason: 'Dữ liệu PDF không phải là Buffer hợp lệ' };
    }
    const s = pdfBuf.toString('latin1');
    const objRegex = /(\d+)\s+(\d+)\s+obj([\s\S]*?)endobj/g;
    const objects = new Map();
    let m;
    while ((m = objRegex.exec(s)) !== null) {
      const key = `${m[1]} ${m[2]} R`;
      objects.set(key, {
        num: parseInt(m[1], 10),
        gen: parseInt(m[2], 10),
        start: m.index,
        end: m.index + m[0].length,
        body: m[3]
      });
    }

    if (objects.size === 0) {
      return { isValid: false, reason: 'Không tìm thấy đối tượng PDF (indirect objects) nào trong tệp' };
    }

    // 1. Định vị đối tượng Catalog (/Type /Catalog)
    let catalog = null;
    let catalogKey = null;
    for (const [key, obj] of objects.entries()) {
      if (/\/Type\s*\/Catalog\b/.test(obj.body)) {
        catalog = obj;
        catalogKey = key;
        break;
      }
    }
    if (!catalog) {
      return { isValid: false, reason: 'Không tìm thấy đối tượng Catalog (/Type /Catalog) trong PDF theo ISO 32000-1' };
    }

    // 2. Định vị và xác thực cấu trúc /AcroForm trong Catalog
    const acroFormRefMatch = catalog.body.match(/\/AcroForm\s+(\d+\s+\d+\s+R)/);
    const acroFormInlineMatch = catalog.body.match(/\/AcroForm\s*<<([\s\S]*?)>>/);
    let acroFormBody = '';
    if (acroFormRefMatch) {
      const acroObj = objects.get(acroFormRefMatch[1]);
      if (!acroObj) {
        return { isValid: false, reason: 'Tham chiếu AcroForm không tồn tại trong danh sách indirect objects của PDF' };
      }
      acroFormBody = acroObj.body;
    } else if (acroFormInlineMatch) {
      acroFormBody = acroFormInlineMatch[1];
    } else {
      return { isValid: false, reason: 'Tệp PDF thiếu cấu trúc AcroForm trong Catalog theo ISO 32000-1' };
    }

    // Kiểm tra /SigFlags: Bắt buộc tồn tại và có giá trị chuẩn (SignaturesExist = 1, AppendOnly = 2)
    const sigFlagsMatch = acroFormBody.match(/\/SigFlags\s+(\d+)/);
    if (!sigFlagsMatch) {
      return { isValid: false, reason: 'AcroForm thiếu thuộc tính /SigFlags theo ISO 32000-1' };
    }
    const sigFlags = parseInt(sigFlagsMatch[1], 10);
    if ((sigFlags & 3) !== 3) {
      return { isValid: false, reason: `/SigFlags phải có giá trị 3 (SignaturesExist + AppendOnly) theo ISO 32000-1 (nhận được: ${sigFlags})` };
    }

    // Kiểm tra /Fields trong AcroForm
    const fieldsMatch = acroFormBody.match(/\/Fields\s*\[([^\]]*)\]/);
    if (!fieldsMatch) {
      return { isValid: false, reason: 'AcroForm thiếu mảng trường chữ ký /Fields' };
    }
    const fieldRefs = [...fieldsMatch[1].matchAll(/(\d+\s+\d+\s+R)/g)].map(x => x[1]);
    if (fieldRefs.length === 0) {
      return { isValid: false, reason: 'AcroForm.Fields rỗng, không chứa trường chữ ký nào' };
    }

    // 3. Định vị Signature Field / Widget trong AcroForm.Fields
    let sigWidget = null;
    let sigWidgetKey = null;
    for (const fRef of fieldRefs) {
      const fObj = objects.get(fRef);
      if (!fObj) continue;
      if (/\/Subtype\s*\/Widget\b/.test(fObj.body) && /\/FT\s*\/Sig\b/.test(fObj.body)) {
        if (sigWidget) {
          return { isValid: false, reason: 'Phát hiện nhiều trường chữ ký gây nhập nhằng trong AcroForm' };
        }
        sigWidget = fObj;
        sigWidgetKey = fRef;
      }
    }
    if (!sigWidget) {
      return { isValid: false, reason: 'Không tìm thấy Signature Widget (/FT /Sig /Subtype /Widget) hợp lệ trong AcroForm.Fields' };
    }

    if (!/\/Type\s*\/Annot\b/.test(sigWidget.body)) {
      return { isValid: false, reason: 'Signature Widget thiếu thuộc tính /Type /Annot theo ISO 32000-1' };
    }

    // 4. Xác thực Signature Widget thực sự nằm trong mảng /Annots của một trang
    let pageHasWidget = false;
    for (const [key, obj] of objects.entries()) {
      if (/\/Type\s*\/Page\b/.test(obj.body)) {
        const annotsMatch = obj.body.match(/\/Annots\s*\[([^\]]*)\]/);
        if (annotsMatch && annotsMatch[1].includes(sigWidgetKey)) {
          pageHasWidget = true;
          break;
        }
      }
    }
    if (!pageHasWidget) {
      return { isValid: false, reason: 'Signature Widget không nằm trong mảng /Annots của bất kỳ trang nào trong tài liệu' };
    }

    // 5. Xác thực Signature Dictionary được trỏ bởi /V của Widget
    const vMatch = sigWidget.body.match(/\/V\s+(\d+\s+\d+\s+R)/);
    if (!vMatch) {
      return { isValid: false, reason: 'Signature Widget thiếu thuộc tính /V liên kết tới Signature Dictionary' };
    }
    const sigDictKey = vMatch[1];
    const sigDictObj = objects.get(sigDictKey);
    if (!sigDictObj) {
      return { isValid: false, reason: 'Đối tượng Signature Dictionary được trỏ bởi Widget /V không tồn tại' };
    }

    if (!/\/Type\s*\/Sig\b/.test(sigDictObj.body)) {
      return { isValid: false, reason: 'Đối tượng được trỏ bởi Widget /V không phải là /Type /Sig theo ISO 32000-1' };
    }
    if (!/\/SubFilter\s*\/(ETSI\.CAdES\.detached|adbe\.pkcs7\.detached)\b/.test(sigDictObj.body)) {
      return { isValid: false, reason: 'Signature Dictionary không có /SubFilter chuẩn PAdES (/ETSI.CAdES.detached)' };
    }

    // 6. Phát hiện Signature Dictionary mồ côi (Orphan /Type /Sig không được liên kết hợp lệ)
    for (const [key, obj] of objects.entries()) {
      if (/\/Type\s*\/Sig\b/.test(obj.body) && key !== sigDictKey) {
        return { isValid: false, reason: `Phát hiện Signature Dictionary mồ côi (${key}) không được liên kết hợp lệ trong tài liệu (Fail-Closed)` };
      }
    }

    // 7. Trích xuất và xác thực /ByteRange và /Contents từ ĐÚNG Signature Dictionary này
    const brMatch = sigDictObj.body.match(/\/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]/);
    if (!brMatch) {
      return { isValid: false, reason: 'Signature Dictionary thiếu thuộc tính /ByteRange' };
    }
    const b0 = parseInt(brMatch[1], 10);
    const b1 = parseInt(brMatch[2], 10);
    const b2 = parseInt(brMatch[3], 10);
    const b3 = parseInt(brMatch[4], 10);

    const contentsMatch = sigDictObj.body.match(/\/Contents\s*<([0-9a-fA-F\s]*)>/);
    if (!contentsMatch) {
      return { isValid: false, reason: 'Signature Dictionary thiếu thuộc tính /Contents' };
    }

    // Đối soát /ByteRange với độ dài tệp PDF thực tế
    if (b0 !== 0 || b2 <= b1 || b2 + b3 !== pdfBuf.length) {
      return { isValid: false, reason: `ByteRange bất thường: [${b0}, ${b1}, ${b2}, ${b3}] vs tổng độ dài ${pdfBuf.length}` };
    }

    // Đối soát vùng ByteRange-gap thực tế trong file
    const rawGap = pdfBuf.subarray(b1, b2);
    if (rawGap.length < 4 || rawGap[0] !== 0x3c || rawGap[rawGap.length - 1] !== 0x3e) {
      return { isValid: false, reason: 'Vùng ByteRange-gap không khớp cấu trúc hex string <...>' };
    }
    const rawHex = rawGap.subarray(1, rawGap.length - 1).toString('latin1').replace(/\s+/g, '');
    const dictHex = contentsMatch[1].replace(/\s+/g, '');
    if (rawHex.toUpperCase() !== dictHex.toUpperCase()) {
      return { isValid: false, reason: 'Dữ liệu /Contents trong Signature Dictionary không khớp với vùng ByteRange-gap' };
    }

    if (rawHex.length % 2 !== 0) {
      return { isValid: false, reason: 'Độ dài hex string trong /Contents phải là số chẵn' };
    }
    if (!/^[0-9a-fA-F]+$/.test(rawHex)) {
      return { isValid: false, reason: 'Vùng /Contents chứa ký tự không phải hex' };
    }

    return {
      isValid: true,
      sigDictKey,
      sigWidgetKey,
      b0, b1, b2, b3,
      hex: rawHex
    };
  }

  verifySignedPdf(signedPdfBuffer) {
    try {
      if (!signedPdfBuffer || !Buffer.isBuffer(signedPdfBuffer)) {
        return { isValid: false, reason: 'Dữ liệu PDF không hợp lệ hoặc rỗng' };
      }

      // 0. Thẩm định toàn diện cây đối tượng ISO 32000-1 và liên kết PAdES
      const objGraph = this._verifyPdfObjectGraph(signedPdfBuffer);
      if (!objGraph.isValid) {
        return { isValid: false, byteRangeIntegrity: false, reason: objGraph.reason };
      }

      const { b0, b1, b2, b3, hex } = objGraph;

      // 1. Tính mã băm tài liệu thực tế trên 2 đoạn ByteRange
      const part1 = signedPdfBuffer.subarray(0, b1);
      const part2 = signedPdfBuffer.subarray(b2, b2 + b3);
      const actualDocHash = crypto.createHash('sha256').update(part1).update(part2).digest();

      // 2. Trích xuất khối HEX /Contents và giải mã CMS DER
      const cmsDer = Buffer.from(hex, 'hex');

      // 4. Phân tích cây ASN.1 CMS ContentInfo -> SignedData (Boundary-checked)
      const contentInfoTLV = parseTLV(cmsDer, 0);
      if (!contentInfoTLV || contentInfoTLV.tag !== 0x30) {
        return { isValid: false, reason: 'Nội dung Contents không phải là ASN.1 SEQUENCE hợp lệ' };
      }
      if (contentInfoTLV.next > cmsDer.length) {
        return { isValid: false, reason: 'Độ dài CMS ContentInfo vượt quá dung lượng giải mã' };
      }

      // 4.1 Kiểm tra Zero-Padding: Phần dư sau CMS DER trong /Contents bắt buộc phải toàn bộ là '0'
      const actualCmsHexLen = contentInfoTLV.next * 2;
      const afterCmsHex = hex.substring(actualCmsHexLen);
      if (!/^0*$/.test(afterCmsHex)) {
        return { isValid: false, reason: 'Vùng đệm Contents chứa dữ liệu bất thường sau CMS (không phải zero padding)' };
      }

      const sdOid = parseTLV(cmsDer, contentInfoTLV.pos + contentInfoTLV.hl);
      if (!sdOid || sdOid.tag !== 0x06 || sdOid.val.toString('hex') !== OID.id_signedData) {
        return { isValid: false, reason: 'Contents không phải là CMS SignedData (OID 1.2.840.113549.1.7.2)' };
      }

      const sdCtx = parseTLV(cmsDer, sdOid.next);
      if (!sdCtx || sdCtx.tag !== 0xa0) return { isValid: false, reason: 'Thiếu SignedData context [0] trong CMS' };
      if (sdCtx.next !== contentInfoTLV.next) return { isValid: false, reason: 'CMS ContentInfo chứa dữ liệu thừa ngoài SignedData container' };

      const sdSeq = parseTLV(sdCtx.val, 0);
      if (!sdSeq || sdSeq.tag !== 0x30 || sdSeq.next !== sdCtx.val.length) {
        return { isValid: false, reason: 'Cấu trúc SignedData SEQUENCE không hợp lệ hoặc chứa trailing bytes' };
      }

      let sP = 0;
      const ver = parseTLV(sdSeq.val, sP); if (!ver || ver.tag !== 0x02) return { isValid: false, reason: 'Thiếu version trong SignedData' }; sP = ver.next;
      const da = parseTLV(sdSeq.val, sP); if (!da || da.tag !== 0x31) return { isValid: false, reason: 'Thiếu digestAlgorithms trong SignedData' }; sP = da.next;
      
      // Kiểm tra cấu trúc và OID của digestAlgorithms trong SignedData
      if (da.val.length === 0) return { isValid: false, reason: 'SignedData.digestAlgorithms rỗng' };
      const daAlgTLV = parseTLV(da.val, 0);
      if (!daAlgTLV || daAlgTLV.tag !== 0x30) return { isValid: false, reason: 'AlgorithmIdentifier trong SignedData.digestAlgorithms không hợp lệ' };
      const daAlgOid = parseTLV(daAlgTLV.val, 0);
      if (!daAlgOid || daAlgOid.tag !== 0x06 || daAlgOid.val.toString('hex') !== OID.sha256) {
        return { isValid: false, reason: 'SignedData.digestAlgorithms không chứa SHA-256 (OID 2.16.840.1.101.3.4.2.1)' };
      }
      if (daAlgTLV.next !== da.val.length) return { isValid: false, reason: 'SignedData.digestAlgorithms SET chứa trailing bytes' };

      const eci = parseTLV(sdSeq.val, sP); if (!eci || eci.tag !== 0x30) return { isValid: false, reason: 'Thiếu encapContentInfo trong SignedData' }; sP = eci.next;
      const certsPart = parseTLV(sdSeq.val, sP); if (!certsPart || certsPart.tag !== 0xa0) return { isValid: false, reason: 'Thiếu certificates trong SignedData' }; sP = certsPart.next;
      const sisPart = parseTLV(sdSeq.val, sP);
      if (!sisPart || sisPart.tag !== 0x31) {
        return { isValid: false, reason: 'CMS không chứa signerInfos SET' };
      }
      sP = sisPart.next;
      if (sP !== sdSeq.val.length) {
        return { isValid: false, reason: 'SignedData SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes)' };
      }

      // 5. Phân tích SignerInfo của người ký
      const siSeq = parseTLV(sisPart.val, 0);
      if (!siSeq || siSeq.tag !== 0x30) return { isValid: false, reason: 'SignerInfo không phải là SEQUENCE' };
      if (siSeq.next !== sisPart.val.length) {
        return { isValid: false, reason: 'signerInfos SET chứa dữ liệu thừa hoặc nhiều SignerInfo ngoài quy chuẩn (Fail-Closed)' };
      }
      let siP = 0;
      const siVer = parseTLV(siSeq.val, siP); if (!siVer || siVer.tag !== 0x02) return { isValid: false, reason: 'Thiếu version trong SignerInfo' }; siP = siVer.next;
      const siSid = parseTLV(siSeq.val, siP); if (!siSid || siSid.tag !== 0x30) return { isValid: false, reason: 'SignerInfo.sid không phải là IssuerAndSerialNumber' }; siP = siSid.next;
      const siDa = parseTLV(siSeq.val, siP); if (!siDa || siDa.tag !== 0x30) return { isValid: false, reason: 'Thiếu digestAlgorithm trong SignerInfo' }; siP = siDa.next;
      const siDaOid = parseTLV(siDa.val, 0);
      if (!siDaOid || siDaOid.tag !== 0x06 || siDaOid.val.toString('hex') !== OID.sha256) {
        return { isValid: false, reason: `Thuật toán digestAlgorithm (${siDaOid ? siDaOid.val.toString('hex') : 'null'}) không phải là SHA-256!` };
      }
      const signedAttrsPart = parseTLV(siSeq.val, siP); if (!signedAttrsPart || signedAttrsPart.tag !== 0xa0) return { isValid: false, reason: 'Thiếu signedAttrs trong SignerInfo' }; siP = signedAttrsPart.next;
      const sigAlg = parseTLV(siSeq.val, siP); if (!sigAlg || sigAlg.tag !== 0x30) return { isValid: false, reason: 'Thiếu signatureAlgorithm trong SignerInfo' }; siP = sigAlg.next;
      const sigVal = parseTLV(siSeq.val, siP); if (!sigVal || sigVal.tag !== 0x04) return { isValid: false, reason: 'Thiếu signatureValue trong SignerInfo' }; siP = sigVal.next;
      
      let unsignedAttrsPart = null;
      if (siP < siSeq.val.length) {
        unsignedAttrsPart = parseTLV(siSeq.val, siP);
        if (!unsignedAttrsPart || unsignedAttrsPart.tag !== 0xa1) return { isValid: false, reason: 'unsignedAttrs không hợp lệ trong SignerInfo' };
        siP = unsignedAttrsPart.next;
      }
      if (siP !== siSeq.val.length) {
        return { isValid: false, reason: 'SignerInfo SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes)' };
      }

      const signatureValue = sigVal.val;

      // 6. Trích xuất chứng thư số người ký khớp CHÍNH XÁC với SignerInfo.sid (cấm fallback, kiểm tra null trước)
      const sidIssuer = parseTLV(siSid.val, 0);
      if (!sidIssuer || sidIssuer.tag !== 0x30) {
        return { isValid: false, reason: 'Issuer trong SignerInfo.sid không hợp lệ (không phải SEQUENCE tag 0x30)' };
      }
      const sidSerial = parseTLV(siSid.val, sidIssuer.next);
      if (!sidSerial || sidSerial.tag !== 0x02) {
        return { isValid: false, reason: 'Serial trong SignerInfo.sid không hợp lệ (không phải INTEGER tag 0x02)' };
      }
      if (sidSerial.next !== siSid.val.length) {
        return { isValid: false, reason: 'SignerInfo.sid chứa dữ liệu thừa ở cuối (trailing bytes)' };
      }

      const targetIssuerDer = siSid.val.subarray(sidIssuer.pos, sidIssuer.next);
      const targetSerialDer = sidSerial.val;

      let signerX509 = null;
      let matchedSignerCertDer = null;
      let matchedSignerCount = 0;
      const allSignerCerts = [];
      let cP = 0;
      while (cP < certsPart.val.length) {
        const cTLV = parseTLV(certsPart.val, cP);
        if (!cTLV || cTLV.tag !== 0x30) {
          return { isValid: false, reason: 'Cấu trúc chứng thư số trong certificates không hợp lệ (Fail-Closed)' };
        }
        const cDer = certsPart.val.subarray(cTLV.pos, cTLV.next);
        const meta = extractIssuerAndSerialFromCert(cDer);
        if (meta && meta.issuerDer.equals(targetIssuerDer) && meta.serialDer.equals(targetSerialDer)) {
          matchedSignerCertDer = cDer;
          matchedSignerCount++;
          try {
            signerX509 = new crypto.X509Certificate(cDer);
          } catch (e) {
            return { isValid: false, reason: `Không thể parse chứng thư X.509 của người ký: ${e.message}` };
          }
        }
        try {
          allSignerCerts.push(new crypto.X509Certificate(cDer));
        } catch (e) {
          return { isValid: false, reason: `Chứng thư trong certificates container không phải là X.509 hợp lệ (Fail-Closed): ${e.message}` };
        }
        cP = cTLV.next;
      }
      if (cP !== certsPart.val.length) {
        return { isValid: false, reason: 'certificates container của người ký chứa trailing bytes chưa được tiêu thụ (Fail-Closed)' };
      }

      if (matchedSignerCount > 1) {
        return { isValid: false, reason: 'Phát hiện nhiều chứng thư trùng khớp SignerInfo.sid (Multiple certificates match SignerInfo.sid)' };
      }
      if (!signerX509 || matchedSignerCount === 0) {
        return { isValid: false, reason: 'Không tìm thấy chứng thư số người ký khớp với IssuerAndSerialNumber trong SignerInfo.sid (Zero Fallback)' };
      }

      // Kiểm tra BasicConstraints của chứng thư người ký: Phải là leaf/end-entity, không được là CA
      if (signerX509.ca === true) {
        return { isValid: false, reason: 'Chứng thư người ký là chứng thư CA, không phải end-entity certificate (Fail-Closed)' };
      }

      // 7. Kiểm tra thời hạn hiệu lực của chứng thư người ký (chống Invalid Date)
      const now = new Date();
      const notBefore = new Date(signerX509.validFrom);
      const notAfter = new Date(signerX509.validTo);
      if (
        Number.isNaN(notBefore.getTime()) ||
        Number.isNaN(notAfter.getTime()) ||
        now < notBefore ||
        now > notAfter
      ) {
        return { isValid: false, reason: `Chứng thư số người ký đã hết hạn hoặc thời hạn không hợp lệ (${signerX509.validFrom} - ${signerX509.validTo})` };
      }

      // 8. Đối soát schema signedAttrs của người ký: Bắt buộc cả contentType (id-data) và messageDigest
      if (signedAttrsPart.val.length === 0) {
        return { isValid: false, reason: 'signedAttrs rỗng (Bắt buộc theo chuẩn CMS/PAdES)' };
      }

      let embeddedMessageDigest = null;
      let embeddedContentType = null;
      let saP = 0;
      const seenAttrs = new Set();
      while (saP < signedAttrsPart.val.length) {
        const attr = parseTLV(signedAttrsPart.val, saP);
        if (!attr || attr.tag !== 0x30) {
          return { isValid: false, reason: 'Cấu trúc thuộc tính trong signedAttrs không hợp lệ (Fail-Closed)' };
        }
        const aOid = parseTLV(attr.val, 0);
        if (!aOid || aOid.tag !== 0x06) {
          return { isValid: false, reason: 'Thuộc tính signedAttrs thiếu OID hợp lệ' };
        }
        const oidHex = aOid.val.toString('hex');
        if (seenAttrs.has(oidHex)) {
          return { isValid: false, reason: `Phát hiện thuộc tính trùng lặp trong signedAttrs (OID ${oidHex}) - Fail-Closed` };
        }
        seenAttrs.add(oidHex);

        const aSet = parseTLV(attr.val, aOid.next);
        if (!aSet || aSet.tag !== 0x31 || aSet.next !== attr.val.length) {
          return { isValid: false, reason: 'Thuộc tính signedAttrs phải là SET có độ dài chính xác' };
        }

        if (oidHex === OID.messageDigest) {
          const aOctet = parseTLV(aSet.val, 0);
          if (!aOctet || aOctet.tag !== 0x04 || aOctet.next !== aSet.val.length || aOctet.val.length !== 32) {
            return { isValid: false, reason: 'Trường messageDigest trong signedAttrs không phải là OCTET STRING 32 bytes (SHA-256) hoặc chứa trailing bytes' };
          }
          embeddedMessageDigest = aOctet.val;
        } else if (oidHex === OID.contentType) {
          const aCtOid = parseTLV(aSet.val, 0);
          if (!aCtOid || aCtOid.tag !== 0x06 || aCtOid.next !== aSet.val.length) {
            return { isValid: false, reason: 'Trường contentType trong signedAttrs không phải là OID hợp lệ hoặc chứa trailing bytes' };
          }
          embeddedContentType = aCtOid.val.toString('hex');
        }
        saP = attr.next;
      }

      if (saP !== signedAttrsPart.val.length) {
        return { isValid: false, reason: 'signedAttrs container chứa trailing bytes chưa được tiêu thụ' };
      }

      if (!embeddedContentType) {
        return { isValid: false, reason: 'Thiếu thuộc tính bắt buộc contentType trong signedAttrs (Yêu cầu CMS RFC 5652)' };
      }
      if (embeddedContentType !== OID.id_data) {
        return { isValid: false, reason: `Thuộc tính contentType (${embeddedContentType}) không phải là id-data (OID 1.2.840.113549.1.7.1)` };
      }
      if (!embeddedMessageDigest) {
        return { isValid: false, reason: 'Thiếu thuộc tính bắt buộc messageDigest trong signedAttrs (Yêu cầu CMS RFC 5652)' };
      }

      if (!actualDocHash.equals(embeddedMessageDigest)) {
        return {
          isValid: false,
          byteRangeIntegrity: false,
          reason: 'Tài liệu đã bị sửa đổi sau khi ký! Mã băm ByteRange không khớp với messageDigest trong CMS SignedData.'
        };
      }

      // 9. Xác minh chữ ký số mật mã học của người ký bằng Public Key trong chứng thư
      const sigAlgOid = parseTLV(sigAlg.val, 0);
      const sigAlgHex = sigAlgOid ? sigAlgOid.val.toString('hex') : '';
      let hashAlg = 'SHA256';
      if (sigAlgHex !== OID.ecdsa_with_SHA256 && sigAlgHex !== OID.sha256WithRSA) {
        return { isValid: false, reason: `Thuật toán chữ ký người ký (${sigAlgHex}) không được hỗ trợ hoặc không an toàn!` };
      }

      // Kiểm tra tham số khóa công khai người ký: Bắt buộc ECDSA curve P-256 hoặc RSA >= 2048
      if (sigAlgHex === OID.ecdsa_with_SHA256) {
        if (signerX509.publicKey.asymmetricKeyType !== 'ec') {
          return { isValid: false, reason: 'Khóa công khai của người ký không phải là Elliptic Curve (EC)' };
        }
        const curveDetails = signerX509.publicKey.asymmetricKeyDetails;
        if (!curveDetails || (curveDetails.namedCurve !== 'prime256v1' && curveDetails.namedCurve !== 'secp256r1')) {
          return { isValid: false, reason: `Đường cong Elliptic Curve (${curveDetails ? curveDetails.namedCurve : 'unknown'}) không phải là P-256 (prime256v1/secp256r1)!` };
        }
      } else if (sigAlgHex === OID.sha256WithRSA) {
        if (signerX509.publicKey.asymmetricKeyType !== 'rsa') {
          return { isValid: false, reason: 'Khóa công khai của người ký không phải là RSA' };
        }
        const rsaDetails = signerX509.publicKey.asymmetricKeyDetails;
        if (rsaDetails && rsaDetails.modulusLength < 2048) {
          return { isValid: false, reason: `Độ dài khóa RSA (${rsaDetails.modulusLength} bits) dưới chuẩn an toàn 2048 bits!` };
        }
      }

      const signedAttrsSet = Buffer.concat([
        Buffer.from([0x31]),
        encodeLength(signedAttrsPart.val.length),
        signedAttrsPart.val
      ]);

      let isSignerSignatureValid = false;
      try {
        const verifier = crypto.createVerify(hashAlg);
        verifier.update(signedAttrsSet);
        verifier.end();
        isSignerSignatureValid = verifier.verify(signerX509.publicKey, signatureValue);
      } catch (errSig) {
        isSignerSignatureValid = false;
      }

      if (!isSignerSignatureValid) {
        return {
          isValid: false,
          signerSignatureValid: false,
          reason: 'Chữ ký số mật mã học của người ký KHÔNG HỢP LỆ! (Không thể xác thực bằng khóa công khai)'
        };
      }

      // 10. BẮT BUỘC PAdES-B-T: Kiểm tra Dấu thời gian điện tử (id-aa-signatureTimeStamp)
      if (!unsignedAttrsPart || unsignedAttrsPart.tag !== 0xa1) {
        return {
          isValid: false,
          reason: 'Chữ ký thiếu Dấu thời gian điện tử trong unsignedAttributes (Bắt buộc theo chuẩn PAdES-B-T)!'
        };
      }

      let hasSignatureTimeStamp = false;
      let isTimeStampImprintValid = false;
      let isTsaCryptoSigValid = false;
      let tsaCertSubject = null;
      let genTime = null;
      let verifiedTsaResult = null;
      let timeStampTokenCount = 0;
      const seenUnsignedAttrs = new Set();

      let uaP = 0;
      while (uaP < unsignedAttrsPart.val.length) {
        const attr = parseTLV(unsignedAttrsPart.val, uaP);
        if (!attr || attr.tag !== 0x30) {
          return { isValid: false, reason: 'Cấu trúc unsignedAttrs không hợp lệ (Fail-Closed)' };
        }
        const aOid = parseTLV(attr.val, 0);
        if (!aOid || aOid.tag !== 0x06) {
          return { isValid: false, reason: 'Thuộc tính unsignedAttrs thiếu OID hợp lệ' };
        }
        const oidHex = aOid.val.toString('hex');
        if (seenUnsignedAttrs.has(oidHex)) {
          return { isValid: false, reason: `Phát hiện thuộc tính trùng lặp trong unsignedAttrs (OID ${oidHex}) - Fail-Closed` };
        }
        seenUnsignedAttrs.add(oidHex);

        const aSet = parseTLV(attr.val, aOid.next);
        if (!aSet || aSet.tag !== 0x31 || aSet.next !== attr.val.length) {
          return { isValid: false, reason: 'Thuộc tính unsignedAttrs phải là SET có độ dài chính xác' };
        }

        if (oidHex === OID.id_aa_sigTimeStamp) {
          hasSignatureTimeStamp = true;
          timeStampTokenCount++;
          if (timeStampTokenCount > 1) {
            return { isValid: false, reason: 'Chữ ký chứa nhiều hơn một id-aa-signatureTimeStamp (Vi phạm tính đơn trị PAdES-B-T)' };
          }
          const tokenTLV = parseTLV(aSet.val, 0);
          if (!tokenTLV || tokenTLV.tag !== 0x30) {
            return { isValid: false, reason: 'TimeStampToken trong unsignedAttrs không phải là SEQUENCE' };
          }
          if (tokenTLV.next !== aSet.val.length) {
            return { isValid: false, reason: 'SET id-aa-signatureTimeStamp chứa nhiều hơn một TimeStampToken hoặc có trailing bytes' };
          }
          const timeStampToken = aSet.val.subarray(tokenTLV.pos, tokenTLV.next);

          const expectedSigHash = crypto.createHash('sha256').update(signatureValue).digest();
          const tsaVerifyResult = this._extractAndVerifyTsaToken(timeStampToken, expectedSigHash);

          if (tsaVerifyResult.isValid) {
            isTimeStampImprintValid = true;
            isTsaCryptoSigValid = true;
            tsaCertSubject = tsaVerifyResult.subject;
            genTime = tsaVerifyResult.genTime;
            verifiedTsaResult = tsaVerifyResult;
          } else {
            return {
              isValid: false,
              reason: 'Dấu thời gian điện tử TSA không hợp lệ: ' + tsaVerifyResult.reason
            };
          }
        }
        uaP = attr.next;
      }

      if (uaP !== unsignedAttrsPart.val.length) {
        return { isValid: false, reason: 'unsignedAttrs container chứa trailing bytes chưa được tiêu thụ' };
      }

      if (!hasSignatureTimeStamp || timeStampTokenCount !== 1) {
        return {
          isValid: false,
          reason: 'Chữ ký thiếu hoặc chứa số lượng Dấu thời gian không hợp lệ trong unsignedAttributes (Bắt buộc đúng 1 theo PAdES-B-T)!'
        };
      }

      return {
        isValid: true,
        byteRangeIntegrity: true,
        messageDigestMatches: true,
        signerSignatureCryptographicallyValid: isSignerSignatureValid,
        signerSubject: signerX509.subject,
        signerIssuer: signerX509.issuer,
        signerSerialNumber: signerX509.serialNumber,
        signerTrustAnchor: 'Self-contained / CMS Embedded (Direct Key Binding)',
        signerTrustChainNote: 'CMS embedded certificate and cryptographic signature verified; VGCA trust-chain and revocation validation deferred to Gateway/OCSP in Phase 3.',
        signerTrustModel: {
          level: 'DIRECT_KEY_BINDING',
          scope: 'CRYPTOGRAPHIC_KEY_BINDING_ONLY',
          trustAnchor: 'Self-contained / CMS Embedded Certificate',
          cryptographicallyBound: true,
          revocationStatus: 'OUT_OF_SCOPE_PHASE2_DEFERRED_TO_PHASE3_GATEWAY',
          note: 'Giai đoạn 2 thẩm định toàn vẹn mật mã học của chữ ký PDF và chứng minh tính hợp lệ của Dấu thời gian PAdES-B-T so với chứng thư nhúng trong CMS. Việc xây dựng trust chain tới VGCA RootCA và kiểm tra trạng thái thu hồi OCSP/CRL thuộc phạm vi Gateway/OCSP ở Giai đoạn 3.'
        },
        hasSignatureTimeStamp: true,
        signatureTimeStampImprintMatches: isTimeStampImprintValid,
        tsaSignatureCryptographicallyValid: isTsaCryptoSigValid,
        tsaSubject: tsaCertSubject,
        tsaTrustAnchor: 'RootCA chuyên dùng Chính phủ G2 (Ban Cơ yếu Chính phủ)',
        tsaTrustModel: {
          level: 'VGCA_PINNED_TRUST_ANCHOR',
          trustAnchor: 'RootCA chuyên dùng Chính phủ G2 (Ban Cơ yếu Chính phủ)',
          certificateFingerprint: verifiedTsaResult ? verifiedTsaResult.fingerprint256 : null,
          isPinned: verifiedTsaResult ? verifiedTsaResult.isPinnedTrustAnchor : false,
          revocationStatus: 'DEFERRED_TO_PHASE3_GATEWAY'
        },
        genTime: genTime,
        reason: 'Tài liệu nguyên vẹn, Chữ ký số người ký (Direct Key Binding) và Dấu thời gian PAdES-B-T Ban Cơ yếu Chính phủ hợp lệ.'
      };
    } catch (err) {
      return { isValid: false, reason: `Lỗi phân tích mật mã PDF: ${err.message}` };
    }
  }

  _extractAndVerifyTsaToken(timeStampToken, expectedSignatureHash, validationTime = new Date()) {
    try {
      const root = parseTLV(timeStampToken, 0);
      if (!root || root.tag !== 0x30 || root.next !== timeStampToken.length) {
        return { isValid: false, reason: 'Token không phải là SEQUENCE hoặc có dữ liệu thừa' };
      }

      const ctOid = parseTLV(timeStampToken, root.pos + root.hl);
      if (!ctOid || ctOid.val.toString('hex') !== OID.id_signedData) {
        return { isValid: false, reason: 'Token không phải là SignedData' };
      }

      const sdCtx = parseTLV(timeStampToken, ctOid.next);
      if (!sdCtx || sdCtx.tag !== 0xa0) return { isValid: false, reason: 'Thiếu SignedData context [0]' };
      if (sdCtx.next !== timeStampToken.length) return { isValid: false, reason: 'TimeStampToken chứa dữ liệu thừa ngoài SignedData container' };

      const sdSeq = parseTLV(sdCtx.val, 0);
      if (!sdSeq || sdSeq.tag !== 0x30 || sdSeq.next !== sdCtx.val.length) {
        return { isValid: false, reason: 'SignedData không phải là SEQUENCE hoặc chứa trailing bytes' };
      }

      let sP = 0;
      const ver = parseTLV(sdSeq.val, sP); if (!ver || ver.tag !== 0x02) return { isValid: false, reason: 'Thiếu version trong SignedData' }; sP = ver.next;
      const da = parseTLV(sdSeq.val, sP); if (!da || da.tag !== 0x31) return { isValid: false, reason: 'Thiếu digestAlgorithms trong SignedData' }; sP = da.next;
      
      // Kiểm tra digestAlgorithms trong TSA SignedData
      if (da.val.length === 0) return { isValid: false, reason: 'TSA SignedData.digestAlgorithms rỗng' };
      const daAlgTLV = parseTLV(da.val, 0);
      if (!daAlgTLV || daAlgTLV.tag !== 0x30) return { isValid: false, reason: 'AlgorithmIdentifier trong TSA SignedData.digestAlgorithms không hợp lệ' };
      const daAlgOid = parseTLV(daAlgTLV.val, 0);
      if (!daAlgOid || daAlgOid.tag !== 0x06 || daAlgOid.val.toString('hex') !== OID.sha256) {
        return { isValid: false, reason: 'TSA SignedData.digestAlgorithms không chứa SHA-256' };
      }
      if (daAlgTLV.next !== da.val.length) return { isValid: false, reason: 'TSA SignedData.digestAlgorithms SET chứa trailing bytes' };

      const eci = parseTLV(sdSeq.val, sP); if (!eci || eci.tag !== 0x30) return { isValid: false, reason: 'Thiếu encapContentInfo trong SignedData' }; sP = eci.next;
      const certsPart = parseTLV(sdSeq.val, sP); if (!certsPart || certsPart.tag !== 0xa0) return { isValid: false, reason: 'Thiếu certificates trong SignedData' }; sP = certsPart.next;
      const sisPart = parseTLV(sdSeq.val, sP); if (!sisPart || sisPart.tag !== 0x31) return { isValid: false, reason: 'Thiếu signerInfos trong SignedData' }; sP = sisPart.next;
      if (sP !== sdSeq.val.length) {
        return { isValid: false, reason: 'TSA SignedData SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes)' };
      }

      const eciOid = parseTLV(eci.val, 0);
      if (!eciOid || eciOid.val.toString('hex') !== '2a864886f70d0109100104') {
        return { isValid: false, reason: 'eContentType không phải là id-ct-TSTInfo' };
      }

      const eContentCtx = parseTLV(eci.val, eciOid.next);
      if (!eContentCtx || eContentCtx.tag !== 0xa0) return { isValid: false, reason: 'Thiếu eContent [0] trong encapContentInfo' };
      const eContentOctet = parseTLV(eContentCtx.val, 0);
      if (!eContentOctet || eContentOctet.tag !== 0x04 || eContentOctet.next !== eContentCtx.val.length) {
        return { isValid: false, reason: 'eContent không phải là OCTET STRING hoặc chứa trailing bytes' };
      }

      const tstInfoDer = eContentOctet.val;
      const expectedTstHash = crypto.createHash('sha256').update(tstInfoDer).digest();

      const tstClient = new TsaClient();
      const tstInfo = tstClient.parseStrictTSTInfo(tstInfoDer);

      if (!expectedSignatureHash.equals(tstInfo.hashedMessage)) {
        return { isValid: false, reason: 'TSTInfo.messageImprint không khớp với băm của chữ ký (signatureValue)' };
      }

      // 4.1 FAIL-CLOSED: Kiểm tra thời gian cấp dấu genTime không vượt quá hiện tại + drift (chống future timestamp)
      const tokenDate = new Date(Date.UTC(
        parseInt(tstInfo.genTime.slice(0, 4), 10),
        parseInt(tstInfo.genTime.slice(4, 6), 10) - 1,
        parseInt(tstInfo.genTime.slice(6, 8), 10),
        parseInt(tstInfo.genTime.slice(8, 10), 10),
        parseInt(tstInfo.genTime.slice(10, 12), 10),
        parseInt(tstInfo.genTime.slice(12, 14), 10)
      ));
      const refTimeMs = validationTime ? validationTime.getTime() : Date.now();
      const maxDriftMs = 15 * 60 * 1000; // 15 phút
      if (tokenDate.getTime() > refTimeMs + maxDriftMs) {
        return { isValid: false, reason: `Thời gian cấp dấu trong tương lai vượt quá giới hạn sai lệch cho phép (${tstInfo.genTime} vs mốc xác thực ${new Date(refTimeMs).toISOString()})` };
      }

      // Xác minh chữ ký RSA của TSA
      const siSeq = parseTLV(sisPart.val, 0);
      if (!siSeq || siSeq.tag !== 0x30) return { isValid: false, reason: 'TSA SignerInfo không phải là SEQUENCE' };
      if (siSeq.next !== sisPart.val.length) {
        return { isValid: false, reason: 'TSA signerInfos SET chứa dữ liệu thừa hoặc nhiều SignerInfo ngoài quy chuẩn' };
      }

      let siP = 0;
      const siVer = parseTLV(siSeq.val, siP); if (!siVer || siVer.tag !== 0x02) return { isValid: false, reason: 'Thiếu version trong TSA SignerInfo' }; siP = siVer.next;
      const siSid = parseTLV(siSeq.val, siP); if (!siSid || siSid.tag !== 0x30) return { isValid: false, reason: 'TSA SignerInfo.sid không phải là IssuerAndSerialNumber' }; siP = siSid.next;
      const siDa = parseTLV(siSeq.val, siP); if (!siDa || siDa.tag !== 0x30) return { isValid: false, reason: 'Thiếu digestAlgorithm trong TSA SignerInfo' }; siP = siDa.next;
      const siDaOid = parseTLV(siDa.val, 0);
      if (!siDaOid || siDaOid.tag !== 0x06 || siDaOid.val.toString('hex') !== OID.sha256) {
        return { isValid: false, reason: 'TSA digestAlgorithm không phải là SHA-256' };
      }
      const signedAttrsPart = parseTLV(siSeq.val, siP); if (!signedAttrsPart || signedAttrsPart.tag !== 0xa0) return { isValid: false, reason: 'Thiếu signedAttrs trong TSA SignerInfo' }; siP = signedAttrsPart.next;
      const sigAlg = parseTLV(siSeq.val, siP); if (!sigAlg || sigAlg.tag !== 0x30) return { isValid: false, reason: 'Thiếu signatureAlgorithm trong TSA SignerInfo' }; siP = sigAlg.next;
      const sigAlgOid = parseTLV(sigAlg.val, 0);
      const sigAlgHex = sigAlgOid ? sigAlgOid.val.toString('hex') : '';
      if (sigAlgHex !== OID.sha256WithRSA) {
        return { isValid: false, reason: `TSA signatureAlgorithm (${sigAlgHex}) không phải là sha256WithRSAEncryption (OID 1.2.840.113549.1.1.11)` };
      }
      const sigVal = parseTLV(siSeq.val, siP); if (!sigVal || sigVal.tag !== 0x04) return { isValid: false, reason: 'Thiếu signatureValue trong TSA SignerInfo' }; siP = sigVal.next;
      if (siP < siSeq.val.length) {
        const tsaUnsignedAttrs = parseTLV(siSeq.val, siP);
        if (!tsaUnsignedAttrs || tsaUnsignedAttrs.tag !== 0xa1) return { isValid: false, reason: 'TSA unsignedAttrs không hợp lệ' };
        siP = tsaUnsignedAttrs.next;
      }
      if (siP !== siSeq.val.length) {
        return { isValid: false, reason: 'TSA SignerInfo SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes)' };
      }

      // Kiểm tra signedAttrs của TSA (Fail-closed nếu có phần tử hỏng hoặc duplicate)
      let saP = 0;
      let tsaMd = null;
      let tsaCt = null;
      const tsaSeenAttrs = new Set();
      while (saP < signedAttrsPart.val.length) {
        const attr = parseTLV(signedAttrsPart.val, saP);
        if (!attr || attr.tag !== 0x30) {
          return { isValid: false, reason: 'Cấu trúc thuộc tính trong TSA signedAttrs không hợp lệ (Fail-Closed)' };
        }
        const aOid = parseTLV(attr.val, 0);
        if (!aOid || aOid.tag !== 0x06) {
          return { isValid: false, reason: 'Thuộc tính TSA signedAttrs thiếu OID hợp lệ' };
        }
        const oidHex = aOid.val.toString('hex');
        if (tsaSeenAttrs.has(oidHex)) {
          return { isValid: false, reason: `Phát hiện thuộc tính trùng lặp trong TSA signedAttrs (OID ${oidHex}) - Fail-Closed` };
        }
        tsaSeenAttrs.add(oidHex);

        const aSet = parseTLV(attr.val, aOid.next);
        if (!aSet || aSet.tag !== 0x31 || aSet.next !== attr.val.length) {
          return { isValid: false, reason: 'Thuộc tính TSA signedAttrs phải là SET có độ dài chính xác' };
        }
        if (oidHex === '2a864886f70d010904') {
          const oct = parseTLV(aSet.val, 0);
          if (oct && oct.tag === 0x04 && oct.next === aSet.val.length) tsaMd = oct.val;
        } else if (oidHex === '2a864886f70d010903') {
          const coid = parseTLV(aSet.val, 0);
          if (coid && coid.tag === 0x06 && coid.next === aSet.val.length) tsaCt = coid.val.toString('hex');
        }
        saP = attr.next;
      }

      if (tsaCt !== '2a864886f70d0109100104') {
        return { isValid: false, reason: 'TSA signedAttrs contentType không phải là id-ct-TSTInfo' };
      }
      if (!tsaMd || !expectedTstHash.equals(tsaMd)) {
        return { isValid: false, reason: 'TSA signedAttrs messageDigest không khớp với mã băm của TSTInfo' };
      }

      // Trích xuất chứng thư TSA khớp CHÍNH XÁC cả Issuer DER và Serial DER (cấm fallback, kiểm tra null trước)
      const sidIssuer = parseTLV(siSid.val, 0);
      if (!sidIssuer || sidIssuer.tag !== 0x30) {
        return { isValid: false, reason: 'TSA SignerInfo.sid issuer không phải là SEQUENCE (tag 0x30)' };
      }
      const sidSerial = parseTLV(siSid.val, sidIssuer.next);
      if (!sidSerial || sidSerial.tag !== 0x02) {
        return { isValid: false, reason: 'TSA SignerInfo.sid serial không phải là INTEGER (tag 0x02)' };
      }
      if (sidSerial.next !== siSid.val.length) {
        return { isValid: false, reason: 'TSA SignerInfo.sid chứa trailing bytes' };
      }

      const targetIssuerDer = siSid.val.subarray(sidIssuer.pos, sidIssuer.next);
      const targetSerialDer = sidSerial.val;

      let matchedTsaCertDer = null;
      let matchedTsaCount = 0;
      const allCerts = [];
      let cP = 0;
      while (cP < certsPart.val.length) {
        const cTLV = parseTLV(certsPart.val, cP);
        if (!cTLV || cTLV.tag !== 0x30) {
          return { isValid: false, reason: 'Cấu trúc chứng thư TSA không hợp lệ trong certificates container (Fail-Closed)' };
        }
        const cDer = certsPart.val.subarray(cTLV.pos, cTLV.next);
        const meta = extractIssuerAndSerialFromCert(cDer);
        if (meta && meta.issuerDer.equals(targetIssuerDer) && meta.serialDer.equals(targetSerialDer)) {
          matchedTsaCertDer = cDer;
          matchedTsaCount++;
        }
        try {
          allCerts.push(new crypto.X509Certificate(cDer));
        } catch (e) {
          return { isValid: false, reason: `Chứng thư trong TSA certificates container không phải là X.509 hợp lệ (Fail-Closed): ${e.message}` };
        }
        cP = cTLV.next;
      }
      if (cP !== certsPart.val.length) {
        return { isValid: false, reason: 'certificates container chứa trailing bytes chưa được tiêu thụ' };
      }

      if (matchedTsaCount > 1) {
        return { isValid: false, reason: 'Phát hiện nhiều chứng thư trùng khớp SignerInfo.sid trong TimeStampToken (Multiple certificates match SignerInfo.sid)' };
      }
      if (!matchedTsaCertDer || matchedTsaCount === 0) {
        return { isValid: false, reason: 'Không tìm thấy chứng thư TSA khớp với IssuerAndSerialNumber trong SignerInfo.sid' };
      }

      const tsaX509 = new crypto.X509Certificate(matchedTsaCertDer);

      // 1. Kiểm tra BasicConstraints và Extended Key Usage của Leaf TSA
      if (tsaX509.ca === true) {
        return { isValid: false, reason: 'Chứng thư TSA là chứng thư CA (vi phạm nguyên tắc Leaf TSA)' };
      }
      if (!hasTimeStampingEKU(tsaX509)) {
        return { isValid: false, reason: 'Chứng thư TSA thiếu ExtendedKeyUsage id-kp-timeStamping (1.3.6.1.5.5.7.3.8) theo RFC 3161!' };
      }

      // 2. Xây dựng và xác minh toàn vẹn chuỗi chứng thư X.509 Path Validation (RFC 5280)
      const OFFICIAL_ROOT_CA_G2_FINGERPRINT = 'F0:4B:A4:B4:59:A7:C9:A1:B9:71:AD:9B:1C:B8:33:E6:95:A8:0C:79:AE:A6:3B:17:4B:66:A7:0E:DF:E2:FD:B8';
      const pathValidation = validateX509CertificatePath(tsaX509, allCerts, OFFICIAL_ROOT_CA_G2_FINGERPRINT);
      if (!pathValidation.isValid) {
        return { isValid: false, reason: pathValidation.reason };
      }
      const rootCaX509 = pathValidation.rootCa;

      // 3. Xác minh vân tay SHA-256 của Leaf TSA (Trust Anchor Pinning)
      const OFFICIAL_VGCA_TSA_PINNED_FINGERPRINTS = new Set([
        'EA:E4:6D:68:A0:B9:21:EC:7C:82:DA:11:C7:54:66:22:2F:49:96:91:2E:53:CA:A4:1E:C7:06:72:CE:95:4B:D6' // Máy chủ cấp dấu thời gian 02 (ca.gov.vn)
      ]);
      const isPinned = OFFICIAL_VGCA_TSA_PINNED_FINGERPRINTS.has(tsaX509.fingerprint256);
      if (!isPinned) {
        return { isValid: false, reason: `Chứng thư TSA không khớp vân tay SHA-256 được ghim cứng của Ban Cơ yếu Chính phủ (Nhận: ${tsaX509.fingerprint256}, Yêu cầu một trong: ${Array.from(OFFICIAL_VGCA_TSA_PINNED_FINGERPRINTS).join(', ')})` };
      }

      // Kiểm tra thời hạn hiệu lực của cả Leaf và RootCA
      const now = validationTime instanceof Date ? validationTime : new Date(validationTime);
      const leafFrom = new Date(tsaX509.validFrom);
      const leafTo = new Date(tsaX509.validTo);
      const rootFrom = new Date(rootCaX509.validFrom);
      const rootTo = new Date(rootCaX509.validTo);
      if (now < leafFrom || now > leafTo || Number.isNaN(leafFrom.getTime()) || Number.isNaN(leafTo.getTime())) {
        return { isValid: false, reason: `Chứng thư TSA đã hết hạn hoặc thời hạn không hợp lệ (${tsaX509.validFrom} - ${tsaX509.validTo})` };
      }
      if (now < rootFrom || now > rootTo || Number.isNaN(rootFrom.getTime()) || Number.isNaN(rootTo.getTime())) {
        return { isValid: false, reason: `RootCA chuyên dùng Chính phủ đã hết hạn (${rootCaX509.validFrom} - ${rootCaX509.validTo})` };
      }

      // Kiểm tra thẩm quyền Ban Cơ yếu Chính phủ
      if (!tsaX509.subject.includes('Ban Cơ yếu Chính phủ') && !tsaX509.issuer.includes('Ban Cơ yếu Chính phủ')) {
        return { isValid: false, reason: 'Chứng thư TSA không thuộc Ban Cơ yếu Chính phủ' };
      }

      // Kiểm tra chữ ký RSA của TSA
      const signedAttrsSet = Buffer.concat([
        Buffer.from([0x31]),
        encodeLength(signedAttrsPart.val.length),
        signedAttrsPart.val
      ]);

      const verifier = crypto.createVerify('RSA-SHA256');
      verifier.update(signedAttrsSet);
      verifier.end();
      const isSigValid = verifier.verify(tsaX509.publicKey, sigVal.val);
      if (!isSigValid) return { isValid: false, reason: 'Chữ ký RSA của máy chủ TSA không hợp lệ' };

      return {
        isValid: true,
        subject: tsaX509.subject,
        issuer: tsaX509.issuer,
        fingerprint256: tsaX509.fingerprint256,
        rootCaFingerprint: rootCaX509.fingerprint256,
        isPinnedTrustAnchor: isPinned,
        isChainCryptographicallyVerified: true,
        isGovRootCa: true,
        genTime: tstInfo.genTime
      };
    } catch (e) {
      return { isValid: false, reason: e.message };
    }
  }
}

module.exports = PdfPadesSigner;
module.exports.PdfPadesSigner = PdfPadesSigner;
module.exports.generateSelfSignedX509 = generateSelfSignedX509;
module.exports.parseTLV = parseTLV;
module.exports.validateX509CertificatePath = validateX509CertificatePath;
module.exports.hasTimeStampingEKU = hasTimeStampingEKU;
module.exports.parseBasicConstraintsFromDer = parseBasicConstraintsFromDer;
module.exports.parseKeyUsageFromDer = parseKeyUsageFromDer;
