/**
 * VGCA TSA CLIENT (RFC 3161 Time Stamping Authority Module)
 * Kết nối & Xác thực Con Dấu Thời Gian Điện Tử Ban Cơ yếu Chính phủ (http://ca.gov.vn/tsa)
 * Tuân thủ triệt để: RFC 3161, ETSI EN 319 422, ETSI EN 319 142 (PAdES-B-T), Nghị định 30/2020/NĐ-CP
 * 
 * Đã thẩm định và hoàn thiện cùng OpenAI Codex Reasoning Engine (Round 6 - Industrial Security):
 * 1. Fail-closed tuyệt đối trong sản xuất (allowMockFallback mặc định false).
 * 2. Parse strictly RFC 3161 mục 2.4.2: version=1, SHA-256 OID, 32-byte imprint, positive serial, valid GeneralizedTime.
 * 3. Ràng buộc tuyệt đối chứng thư TSA theo Issuer DER và Serial DER chính xác trong SignerInfo.sid (cấm fallback).
 * 4. Kiểm định toàn vẹn TSA signedAttrs: messageDigest khớp SHA-256(TSTInfo), contentType là id-ct-TSTInfo.
 * 5. Xác minh thời hạn hiệu lực (validFrom <= now <= validTo) và thẩm quyền Ban Cơ yếu Chính phủ.
 */

const http = require('http');
const https = require('https');
const crypto = require('crypto');

// ASN.1 DER Parser & Boundary-checked Helpers (Strict Canonical DER)
function parseTLV(buf, p = 0) {
  if (!buf || !Buffer.isBuffer(buf) || p < 0 || p + 2 > buf.length) return null;
  const tag = buf[p];
  let len = buf[p + 1];
  let hl = 2;
  if (len & 0x80) {
    const n = len & 0x7f;
    // Canonical DER: n must be between 1 and 4 (0 is indefinite length which is forbidden in DER)
    if (n === 0 || n > 4 || p + 2 + n > buf.length) return null;
    // Canonical DER: First octet of long form length MUST NOT be 0x00 (leading zero is forbidden)
    if (buf[p + 2] === 0x00) return null;
    len = 0;
    for (let i = 0; i < n; i++) len = len * 256 + buf[p + 2 + i];
    // Canonical DER: Long form MUST NOT be used for lengths < 128
    if (len < 128) return null;
    hl = 2 + n;
  }
  const next = p + hl + len;
  if (len < 0 || next > buf.length) return null;
  return { tag, len, hl, pos: p, next, val: buf.subarray(p + hl, next) };
}

function encodeLength(len) {
  if (typeof len !== 'number' || !Number.isSafeInteger(len) || len < 0) {
    throw new Error(`Độ dài DER không hợp lệ: ${len}`);
  }
  if (len < 128) return Buffer.from([len]);
  if (len < 256) return Buffer.from([0x81, len]);
  if (len < 65536) return Buffer.from([0x82, (len >> 8) & 0xff, len & 0xff]);
  if (len <= 0xffffff) return Buffer.from([0x83, (len >> 16) & 0xff, (len >> 8) & 0xff, len & 0xff]);
  if (len <= 0xffffffff) return Buffer.from([0x84, (len >>> 24) & 0xff, (len >>> 16) & 0xff, (len >>> 8) & 0xff, len & 0xff]);
  throw new Error(`Độ dài DER vượt quá giới hạn 4GB: ${len}`);
}

function encodeTLV(tag, val) {
  const vBuf = Buffer.isBuffer(val) ? val : Buffer.from(val);
  const lBuf = encodeLength(vBuf.length);
  return Buffer.concat([Buffer.from([tag]), lBuf, vBuf]);
}

function encodeSeq(items) {
  return encodeTLV(0x30, Buffer.concat(items));
}

function encodeSet(items) {
  return encodeTLV(0x31, Buffer.concat(items));
}

function encodeOctetString(buf) {
  return encodeTLV(0x04, buf);
}

function encodeOID(hex) {
  return encodeTLV(0x06, Buffer.from(hex, 'hex'));
}

function encodeCanonicalInteger(bufOrNum) {
  let buf;
  if (typeof bufOrNum === 'bigint') {
    if (bufOrNum < 0n) throw new Error('Số BigInt âm không được hỗ trợ');
    let hex = bufOrNum.toString(16);
    if (hex.length % 2 !== 0) hex = '0' + hex;
    buf = Buffer.from(hex, 'hex');
  } else if (typeof bufOrNum === 'number') {
    if (!Number.isSafeInteger(bufOrNum) || bufOrNum < 0) {
      throw new Error('Số nguyên không hợp lệ hoặc âm cho encodeCanonicalInteger');
    }
    if (bufOrNum === 0) return Buffer.from([0x02, 0x01, 0x00]);
    let hex = Math.floor(bufOrNum).toString(16);
    if (hex.length % 2 !== 0) hex = '0' + hex;
    buf = Buffer.from(hex, 'hex');
  } else if (Buffer.isBuffer(bufOrNum)) {
    if (bufOrNum.length === 0) return Buffer.from([0x02, 0x01, 0x00]);
    buf = Buffer.from(bufOrNum);
  } else {
    throw new Error('Kiểu dữ liệu không được hỗ trợ cho encodeCanonicalInteger');
  }
  let start = 0;
  while (start < buf.length - 1 && buf[start] === 0x00) start++;
  let trimmed = buf.subarray(start);
  if (trimmed[0] & 0x80) trimmed = Buffer.concat([Buffer.from([0x00]), trimmed]);
  return encodeTLV(0x02, trimmed);
}

function encodeUTCTime(date = new Date()) {
  const pad = n => String(n).padStart(2, '0');
  const str = String(date.getUTCFullYear()).slice(2) +
    pad(date.getUTCMonth() + 1) +
    pad(date.getUTCDate()) +
    pad(date.getUTCHours()) +
    pad(date.getUTCMinutes()) +
    pad(date.getUTCSeconds()) + 'Z';
  return encodeTLV(0x17, Buffer.from(str, 'ascii'));
}

function extractIssuerAndSerialFromCert(certDer) {
  const certTLV = parseTLV(certDer, 0);
  if (!certTLV || certTLV.tag !== 0x30 || certTLV.next !== certDer.length) return null;
  const tbsCert = parseTLV(certTLV.val, 0);
  if (!tbsCert || tbsCert.tag !== 0x30) return null;

  let p = 0;
  const first = parseTLV(tbsCert.val, p);
  if (!first) return null;
  let sn, sigAlg, issuer;
  if (first.tag === 0xa0) {
    p = first.next;
    sn = parseTLV(tbsCert.val, p);
  } else {
    sn = first;
  }
  if (!sn) return null;
  p = sn.next;
  sigAlg = parseTLV(tbsCert.val, p);
  if (!sigAlg) return null;
  p = sigAlg.next;
  issuer = parseTLV(tbsCert.val, p);
  if (!issuer) return null;

  return {
    issuerDer: tbsCert.val.subarray(issuer.pos, issuer.next),
    serialDer: sn.val
  };
}

/**
 * Trích xuất BasicConstraints (2.5.29.19) từ DER theo RFC 5280
 * Kiểm tra biên toàn vẹn: Không cho phép trailing bytes, kiểm tra canonical INTEGER và BOOLEAN
 */
function parseBasicConstraintsFromDer(rawDer) {
  try {
    if (!rawDer || !Buffer.isBuffer(rawDer)) return { isCA: false, pathLenConstraint: undefined };
    const certSeq = parseTLV(rawDer, 0);
    if (!certSeq || certSeq.tag !== 0x30 || certSeq.next !== rawDer.length) {
      return { isCA: false, pathLenConstraint: undefined };
    }

    const tbsCert = parseTLV(certSeq.val, 0);
    if (!tbsCert || tbsCert.tag !== 0x30) return { isCA: false, pathLenConstraint: undefined };

    let p = 0;
    let extensionsTLV = null;
    while (p < tbsCert.val.length) {
      const item = parseTLV(tbsCert.val, p);
      if (!item) break;
      if (item.tag === 0xa3) {
        extensionsTLV = item;
        break;
      }
      p = item.next;
    }
    if (!extensionsTLV) return { isCA: false, pathLenConstraint: undefined };

    const extsSeq = parseTLV(extensionsTLV.val, 0);
    if (!extsSeq || extsSeq.tag !== 0x30 || extsSeq.next !== extensionsTLV.val.length) {
      return { isCA: false, pathLenConstraint: undefined };
    }

    let ep = 0;
    while (ep < extsSeq.val.length) {
      const ext = parseTLV(extsSeq.val, ep);
      if (!ext || ext.tag !== 0x30) break;

      let itemP = 0;
      const oid = parseTLV(ext.val, itemP);
      if (oid && oid.tag === 0x06) {
        itemP = oid.next;
        let nextTLV = parseTLV(ext.val, itemP);
        if (nextTLV && nextTLV.tag === 0x01) { // critical BOOLEAN
          itemP = nextTLV.next;
          nextTLV = parseTLV(ext.val, itemP);
        }

        if (nextTLV && nextTLV.tag === 0x04 && nextTLV.next === ext.val.length) {
          if (oid.val.equals(Buffer.from('551d13', 'hex'))) { // 2.5.29.19
            const bcSeq = parseTLV(nextTLV.val, 0);
            if (!bcSeq || bcSeq.tag !== 0x30 || bcSeq.next !== nextTLV.val.length) {
              return { isCA: false, pathLenConstraint: undefined };
            }

            let isCA = false;
            let pathLenConstraint = undefined;
            let bp = 0;

            if (bp < bcSeq.val.length) {
              const first = parseTLV(bcSeq.val, bp);
              if (!first) return { isCA: false, pathLenConstraint: undefined };
              bp = first.next;

              if (first.tag === 0x01) { // cA BOOLEAN
                // Canonical DER (X.690 11.1): BOOLEAN length must be 1, and value must be 0x00 (FALSE) or 0xff (TRUE)
                if (first.len !== 1 || (first.val[0] !== 0x00 && first.val[0] !== 0xff)) {
                  return { isCA: false, pathLenConstraint: undefined };
                }
                isCA = first.val[0] === 0xff;

                if (bp < bcSeq.val.length) {
                  const second = parseTLV(bcSeq.val, bp);
                  if (!second || second.tag !== 0x02) return { isCA: false, pathLenConstraint: undefined };
                  bp = second.next;

                  // Kiểm tra canonical INTEGER
                  if (second.len === 0 || second.len > 4) return { isCA: false, pathLenConstraint: undefined };
                  if ((second.val[0] & 0x80) !== 0) return { isCA: false, pathLenConstraint: undefined };
                  if (second.len > 1 && second.val[0] === 0x00 && (second.val[1] & 0x80) === 0) {
                    return { isCA: false, pathLenConstraint: undefined };
                  }
                  let val = 0;
                  for (let i = 0; i < second.val.length; i++) {
                    val = val * 256 + second.val[i];
                  }
                  pathLenConstraint = val;
                }
              } else if (first.tag === 0x02) {
                // cA bị bỏ qua (mặc định FALSE), trường đầu tiên là pathLenConstraint
                if (first.len === 0 || first.len > 4) return { isCA: false, pathLenConstraint: undefined };
                if ((first.val[0] & 0x80) !== 0) return { isCA: false, pathLenConstraint: undefined };
                if (first.len > 1 && first.val[0] === 0x00 && (first.val[1] & 0x80) === 0) {
                  return { isCA: false, pathLenConstraint: undefined };
                }
                let val = 0;
                for (let i = 0; i < first.val.length; i++) {
                  val = val * 256 + first.val[i];
                }
                pathLenConstraint = val;
              } else {
                return { isCA: false, pathLenConstraint: undefined };
              }
            }

            // Bắt buộc toàn bộ dữ liệu trong bcSeq phải được tiêu thụ
            if (bp !== bcSeq.val.length) {
              return { isCA: false, pathLenConstraint: undefined };
            }
            return { isCA, pathLenConstraint };
          }
        }
      }
      ep = ext.next;
    }
    return { isCA: false, pathLenConstraint: undefined };
  } catch (_) {
    return { isCA: false, pathLenConstraint: undefined };
  }
}

/**
 * Trích xuất KeyUsage (2.5.29.15) từ DER theo RFC 5280
 * Kiểm tra biên toàn vẹn: Không cho phép trailing bytes, kiểm tra BIT STRING
 */
function parseKeyUsageFromDer(rawDer) {
  try {
    if (!rawDer || !Buffer.isBuffer(rawDer)) return { status: 'ABSENT', hasKeyUsage: false, keyCertSign: false };
    const certSeq = parseTLV(rawDer, 0);
    if (!certSeq || certSeq.tag !== 0x30 || certSeq.next !== rawDer.length) {
      return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'Cert not valid DER sequence or has trailing bytes' };
    }

    const tbsCert = parseTLV(certSeq.val, 0);
    if (!tbsCert || tbsCert.tag !== 0x30) return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'tbsCertificate not SEQUENCE' };

    let p = 0;
    let extensionsTLV = null;
    while (p < tbsCert.val.length) {
      const item = parseTLV(tbsCert.val, p);
      if (!item) break;
      if (item.tag === 0xa3) {
        extensionsTLV = item;
        break;
      }
      p = item.next;
    }
    if (!extensionsTLV) return { status: 'ABSENT', hasKeyUsage: false, keyCertSign: false };

    const extsSeq = parseTLV(extensionsTLV.val, 0);
    if (!extsSeq || extsSeq.tag !== 0x30 || extsSeq.next !== extensionsTLV.val.length) {
      return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'Extensions not valid SEQUENCE or has trailing bytes' };
    }

    let ep = 0;
    while (ep < extsSeq.val.length) {
      const ext = parseTLV(extsSeq.val, ep);
      if (!ext || ext.tag !== 0x30) break;

      let itemP = 0;
      const oid = parseTLV(ext.val, itemP);
      if (oid && oid.tag === 0x06) {
        itemP = oid.next;
        let nextTLV = parseTLV(ext.val, itemP);
        if (nextTLV && nextTLV.tag === 0x01) {
          itemP = nextTLV.next;
          nextTLV = parseTLV(ext.val, itemP);
        }

        if (nextTLV && nextTLV.tag === 0x04 && nextTLV.next === ext.val.length) {
          if (oid.val.equals(Buffer.from('551d0f', 'hex'))) { // 2.5.29.15
            const bitString = parseTLV(nextTLV.val, 0);
            if (!bitString || bitString.tag !== 0x03 || bitString.next !== nextTLV.val.length || bitString.val.length < 2) {
              return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'KeyUsage BIT STRING malformed or length < 2' };
            }
            const unusedBits = bitString.val[0];
            // Canonical DER (X.690 11.2.1): unusedBits must be between 0 and 7
            if (unusedBits > 7) return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'unusedBits > 7' };
            // Canonical DER (X.690 11.2.2): The unused bits in the final octet SHALL be zero
            const lastByte = bitString.val[bitString.val.length - 1];
            const unusedMask = (1 << unusedBits) - 1;
            if ((lastByte & unusedMask) !== 0) {
              return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'Unused bits are not zero' };
            }
            // Canonical DER for NamedBitList: trailing all-zero octets are forbidden if bitString.len > 2
            if (bitString.val.length > 2 && lastByte === 0 && unusedBits === 0) {
              return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'Trailing zero octet in NamedBitList' };
            }
            const byte0 = bitString.val[1];
            // Bit 5 là keyCertSign (0x04) theo RFC 5280 4.2.1.3
            const hasKeyCertSign = (byte0 & 0x04) !== 0;
            return { status: 'VALID', hasKeyUsage: true, keyCertSign: hasKeyCertSign, rawByte: byte0 };
          }
        }
      }
      ep = ext.next;
    }
    return { status: 'ABSENT', hasKeyUsage: false, keyCertSign: false };
  } catch (_) {
    return { status: 'MALFORMED', hasKeyUsage: false, keyCertSign: false, reason: 'Exception in parseKeyUsageFromDer' };
  }
}

/**
 * Kiểm tra ExtendedKeyUsage id-kp-timeStamping (1.3.6.1.5.5.7.3.8) theo RFC 3161
 * Bắt buộc parse cấu trúc chuẩn ASN.1 DER với kiểm tra biên triệt để
 */
function hasTimeStampingEKU(x509Cert) {
  try {
    const rawDer = x509Cert.raw;
    if (!rawDer || !Buffer.isBuffer(rawDer)) return false;

    const certSeq = parseTLV(rawDer, 0);
    if (!certSeq || certSeq.tag !== 0x30 || certSeq.next !== rawDer.length) return false;

    const tbsCert = parseTLV(certSeq.val, 0);
    if (!tbsCert || tbsCert.tag !== 0x30) return false;

    let p = 0;
    let extensionsTLV = null;
    while (p < tbsCert.val.length) {
      const item = parseTLV(tbsCert.val, p);
      if (!item) break;
      if (item.tag === 0xa3) { // [3] EXPLICIT Extensions
        extensionsTLV = item;
        break;
      }
      p = item.next;
    }

    if (!extensionsTLV) return false;

    const extsSeq = parseTLV(extensionsTLV.val, 0);
    if (!extsSeq || extsSeq.tag !== 0x30 || extsSeq.next !== extensionsTLV.val.length) return false;

    let extP = 0;
    while (extP < extsSeq.val.length) {
      const extTLV = parseTLV(extsSeq.val, extP);
      if (!extTLV || extTLV.tag !== 0x30) break;

      let itemP = 0;
      const extnIdTLV = parseTLV(extTLV.val, itemP);
      if (extnIdTLV && extnIdTLV.tag === 0x06) {
        itemP = extnIdTLV.next;
        let nextTLV = parseTLV(extTLV.val, itemP);
        if (nextTLV && nextTLV.tag === 0x01) {
          itemP = nextTLV.next;
          nextTLV = parseTLV(extTLV.val, itemP);
        }

        if (nextTLV && nextTLV.tag === 0x04 && nextTLV.next === extTLV.val.length) {
          if (extnIdTLV.val.equals(Buffer.from('551d25', 'hex'))) { // 2.5.29.37
            const ekuSyntaxSeq = parseTLV(nextTLV.val, 0);
            if (ekuSyntaxSeq && ekuSyntaxSeq.tag === 0x30 && ekuSyntaxSeq.next === nextTLV.val.length) {
              let ekuP = 0;
              while (ekuP < ekuSyntaxSeq.val.length) {
                const oidTLV = parseTLV(ekuSyntaxSeq.val, ekuP);
                if (oidTLV && oidTLV.tag === 0x06) {
                  // 1.3.6.1.5.5.7.3.8 (id-kp-timeStamping) -> bytes: 2b 06 01 05 05 07 03 08
                  if (oidTLV.val.equals(Buffer.from('2b06010505070308', 'hex'))) {
                    return true;
                  }
                }
                if (!oidTLV) break;
                ekuP = oidTLV.next;
              }
            }
          }
        }
      }
      extP = extTLV.next;
    }
  } catch (_) {
    return false;
  }
  return false;
}

/**
 * Xây dựng và xác thực chuỗi chứng thư X.509 Path Validation theo RFC 5280
 * Hỗ trợ chuỗi trực tiếp 2 tầng (Leaf -> Root) hoặc đa tầng (Leaf -> Intermediate -> Root)
 * 
 * Các chốt chặn mật mã bắt buộc (RFC 5280 Invariants):
 * 1. Root CA tự ký phải có BasicConstraints cA=TRUE trong DER, chữ ký tự ký hợp lệ. Cấm tin cờ metadata.
 * 2. Bắt buộc kết thúc tại Root CA đã ghim (Chain Termination Invariant):
 *    chain[chain.length - 1].fingerprint256 === officialRootFingerprint (nếu có).
 * 3. Kiểm tra thời hạn hiệu lực (validFrom <= now <= validTo) của TẤT CẢ các chứng thư trong chuỗi (Leaf, Intermediates, Root).
 * 4. Mọi CA cấp phát trong chuỗi bắt buộc có BasicConstraints cA=TRUE trong DER.
 * 5. Mọi CA cấp phát có extension KeyUsage bắt buộc phải có bit keyCertSign (RFC 5280 4.2.1.3).
 * 6. Kiểm tra pathLenConstraint cho TẤT CẢ các CA (Root CA và Intermediate CAs) theo RFC 5280 4.2.1.9.
 * 7. Từng mắt xích subjectCert được xác minh chữ ký mật mã bằng khóa công khai của issuerCert.
 */
function validateX509CertificatePath(leafCert, allCerts, officialRootFingerprint, options = {}) {
  if (!leafCert || !Array.isArray(allCerts) || allCerts.length === 0) {
    return { isValid: false, reason: 'Dữ liệu đầu vào không hợp lệ để xây dựng chuỗi chứng thư' };
  }

  // 1. Xác định Root CA mục tiêu (bắt buộc chứng minh cA=TRUE từ BasicConstraints DER)
  let rootCa = null;
  if (officialRootFingerprint) {
    rootCa = allCerts.find(c => {
      const bc = parseBasicConstraintsFromDer(c.raw);
      return bc.isCA === true && c.subject === c.issuer && c.fingerprint256 === officialRootFingerprint;
    });
    if (!rootCa) {
      return { 
        isValid: false, 
        reason: `Không tìm thấy Root CA tự ký có BasicConstraints cA=TRUE khớp với vân tay đã ghim cứng của Ban Cơ yếu Chính phủ (${officialRootFingerprint})` 
      };
    }
  } else {
    const rootCandidates = allCerts.filter(c => {
      const bc = parseBasicConstraintsFromDer(c.raw);
      return bc.isCA === true && c.subject === c.issuer;
    });
    if (rootCandidates.length === 0) {
      return { isValid: false, reason: 'Không tìm thấy Root CA tự ký có BasicConstraints cA=TRUE trong chuỗi chứng thư' };
    }
    rootCa = rootCandidates[0];
  }

  // 2. Xác thực chữ ký tự ký của Root CA
  if (!rootCa.verify(rootCa.publicKey)) {
    return { isValid: false, reason: 'Chữ ký tự ký của Root CA không hợp lệ' };
  }

  // 3. Kiểm tra BasicConstraints và KeyUsage của Root CA
  const rootBc = parseBasicConstraintsFromDer(rootCa.raw);
  if (!rootBc.isCA) {
    return { isValid: false, reason: 'Root CA thiếu thuộc tính BasicConstraints cA=TRUE trong DER' };
  }
  const rootKu = parseKeyUsageFromDer(rootCa.raw);
  if (rootKu.hasKeyUsage && !rootKu.keyCertSign) {
    return { isValid: false, reason: 'Root CA có extension KeyUsage nhưng thiếu quyền keyCertSign theo RFC 5280' };
  }

  // 4. Xây dựng chuỗi chứng thư từ leafCert đi lên
  const chain = [leafCert];
  let current = leafCert;
  const visited = new Set([leafCert.fingerprint256]);
  const maxChainLength = options.maxChainLength || 5;

  while (current.subject !== current.issuer) {
    if (chain.length >= maxChainLength) {
      return { isValid: false, reason: `Độ dài chuỗi chứng thư vượt quá giới hạn an toàn (${maxChainLength})` };
    }

    let issuer = allCerts.find(c => current.checkIssued(c) && !visited.has(c.fingerprint256));
    if (!issuer && current.checkIssued(rootCa)) {
      issuer = rootCa;
    }

    if (!issuer) {
      return { isValid: false, reason: `Không tìm thấy chứng thư cấp phát cho: ${current.subject}` };
    }

    visited.add(issuer.fingerprint256);
    chain.push(issuer);
    current = issuer;

    if (current.fingerprint256 === rootCa.fingerprint256) {
      break;
    }
  }

  // 5. [CODEX INVARIANT]: Bắt buộc chuỗi kết thúc chính xác tại Root CA đã ghim
  const lastCert = chain[chain.length - 1];
  if (lastCert.fingerprint256 !== rootCa.fingerprint256) {
    return { 
      isValid: false, 
      reason: `Chuỗi chứng thư không kết thúc tại Root CA được tin cậy (Kết thúc tại: ${lastCert.subject}, Vân tay: ${lastCert.fingerprint256})` 
    };
  }
  if (officialRootFingerprint && lastCert.fingerprint256 !== officialRootFingerprint) {
    return {
      isValid: false,
      reason: `Chuỗi chứng thư không kết thúc tại Root CA đã ghim cứng của Ban Cơ yếu Chính phủ (Nhận: ${lastCert.fingerprint256}, Yêu cầu: ${officialRootFingerprint})`
    };
  }

  // 6. Kiểm tra thời hạn hiệu lực của TẤT CẢ chứng thư trong chuỗi (Leaf, Intermediates, Root)
  const now = options.validationTime ? new Date(options.validationTime) : new Date();
  for (let idx = 0; idx < chain.length; idx++) {
    const cert = chain[idx];
    const from = new Date(cert.validFrom);
    const to = new Date(cert.validTo);
    if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || now < from || now > to) {
      const roleStr = idx === 0 ? 'Leaf' : (idx === chain.length - 1 ? 'Root CA' : `Intermediate CA (${idx})`);
      return { 
        isValid: false, 
        reason: `Chứng thư [${roleStr}] ${cert.subject} đã hết hạn hoặc chưa có hiệu lực (${cert.validFrom} - ${cert.validTo})` 
      };
    }
  }

  // 7. Xác thực từng mắt xích CA trong chuỗi (RFC 5280 Path Validation)
  for (let i = 0; i < chain.length - 1; i++) {
    const subjectCert = chain[i];
    const issuerCert = chain[i + 1];

    // a) Chứng thư cấp phát phải là CA (chứng minh từ BasicConstraints DER)
    const issuerBc = parseBasicConstraintsFromDer(issuerCert.raw);
    if (!issuerBc.isCA) {
      return { isValid: false, reason: `Chứng thư cấp phát ${issuerCert.subject} không có BasicConstraints cA=TRUE trong DER` };
    }

    // b) Kiểm tra KeyUsage: Nếu có KeyUsage, bắt buộc phải có quyền keyCertSign; nếu malformed phải fail-closed
    const issuerKu = parseKeyUsageFromDer(issuerCert.raw);
    if (issuerKu.status === 'MALFORMED') {
      return { 
        isValid: false, 
        reason: `Chứng thư cấp phát ${issuerCert.subject} chứa extension KeyUsage không đúng chuẩn DER (MALFORMED): ${issuerKu.reason || 'Invalid DER encoding'}` 
      };
    }
    if (issuerKu.hasKeyUsage && !issuerKu.keyCertSign) {
      return { 
        isValid: false, 
        reason: `Chứng thư cấp phát ${issuerCert.subject} có extension KeyUsage nhưng thiếu quyền keyCertSign theo RFC 5280` 
      };
    }

    // c) Chữ ký số mật mã của subjectCert phải được xác minh bởi khóa của issuerCert
    if (!subjectCert.verify(issuerCert.publicKey)) {
      return { 
        isValid: false, 
        reason: `Chữ ký của ${subjectCert.subject} không được xác minh bởi khóa của ${issuerCert.subject}` 
      };
    }
  }

  // 8. Kiểm tra pathLenConstraint cho TẤT CẢ các CA trong chuỗi (RFC 5280 Section 4.2.1.9)
  for (let j = 1; j < chain.length; j++) {
    const caCert = chain[j];
    const caBc = parseBasicConstraintsFromDer(caCert.raw);
    if (caBc.pathLenConstraint !== undefined) {
      let nonSelfIssuedIntermediates = 0;
      for (let k = 1; k < j; k++) {
        if (chain[k].subject !== chain[k].issuer) {
          nonSelfIssuedIntermediates++;
        }
      }
      if (nonSelfIssuedIntermediates > caBc.pathLenConstraint) {
        return { 
          isValid: false, 
          reason: `Chuỗi chứng thư vi phạm pathLenConstraint (${caBc.pathLenConstraint}) của CA ${caCert.subject} (có ${nonSelfIssuedIntermediates} intermediate CAs bên dưới)` 
        };
      }
    }
  }

  return { isValid: true, chain: chain, rootCa: rootCa };
}

class TsaClient {
  constructor(options = {}) {
    this.tsaUrl = options.tsaUrl || process.env.VGCA_TSA_URL || 'http://ca.gov.vn/tsa';
    this.timeoutMs = options.timeoutMs || 15000;
    this.maxRetries = options.maxRetries !== undefined ? options.maxRetries : 2;
    this.retryDelayMs = options.retryDelayMs || 1000;
    this.allowMockFallback = options.allowMockFallback || false;

    // Khóa chặt mock fallback: Cấm tuyệt đối trong môi trường sản xuất (NODE_ENV=production)
    if (process.env.NODE_ENV === 'production' && this.allowMockFallback) {
      throw new Error('[TSA CRITICAL]: Mock fallback bị vô hiệu hóa tuyệt đối trong môi trường sản xuất (NODE_ENV=production)');
    }

    // Danh sách vân tay SHA-256 chứng thư TSA Ban Cơ yếu Chính phủ được ghim cứng (Certificate Pinning)
    if (process.env.NODE_ENV === 'production') {
      if (options.enforceTsaPinning === false) {
        throw new Error('[TSA CRITICAL]: Vô hiệu hóa Certificate Pinning (enforceTsaPinning: false) bị CẤM TUYỆT ĐỐI trong môi trường sản xuất (NODE_ENV=production)!');
      }
      this.enforceTsaPinning = true;
    } else {
      this.enforceTsaPinning = options.enforceTsaPinning !== undefined ? options.enforceTsaPinning : true;
    }
    this.pinnedFingerprints = new Set([
      'EA:E4:6D:68:A0:B9:21:EC:7C:82:DA:11:C7:54:66:22:2F:49:96:91:2E:53:CA:A4:1E:C7:06:72:CE:95:4B:D6' // Máy chủ cấp dấu thời gian 02 (ca.gov.vn)
    ]);
    this.allowedPolicies = options.allowedPolicies || null;

    // Kiểm tra danh mục máy chủ cấp dấu thời gian được Ban Cơ yếu Chính phủ ủy quyền
    const ALLOWED_TSA_HOSTS = ['ca.gov.vn', 'tsa.ca.gov.vn'];
    if (process.env.NODE_ENV !== 'production') {
      ALLOWED_TSA_HOSTS.push('localhost', '127.0.0.1');
    }
    try {
      const parsed = new URL(this.tsaUrl);
      if (!ALLOWED_TSA_HOSTS.includes(parsed.hostname)) {
        throw new Error(`Máy chủ TSA '${parsed.hostname}' không nằm trong danh mục cơ quan Ban Cơ yếu Chính phủ cấp phép.`);
      }
    } catch (e) {
      throw new Error(`[TSA URL INVALID]: ${e.message}`);
    }
  }

  buildTimeStampReq(hashBuffer) {
    if (!Buffer.isBuffer(hashBuffer) || hashBuffer.length !== 32) {
      throw new Error('[TSA ERROR]: Mã băm phải là Buffer 32 bytes (SHA-256).');
    }

    const sha256AlgId = Buffer.from([
      0x30, 0x0d,
      0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01,
      0x05, 0x00
    ]);

    const octet = Buffer.concat([Buffer.from([0x04, 0x20]), hashBuffer]);
    const imprint = Buffer.concat([Buffer.from([0x30, 0x31]), sha256AlgId, octet]);
    const version = Buffer.from([0x02, 0x01, 0x01]);

    const rawNonce = crypto.randomBytes(8);
    rawNonce[0] = rawNonce[0] & 0x7f;
    if (rawNonce[0] === 0) rawNonce[0] = 1;
    const nonceDer = encodeCanonicalInteger(rawNonce);

    const certReq = Buffer.from([0x01, 0x01, 0xff]);

    const body = Buffer.concat([version, imprint, nonceDer, certReq]);
    const header = Buffer.concat([Buffer.from([0x30]), encodeLength(body.length)]);
    const tspReq = Buffer.concat([header, body]);

    return {
      tspReqBuffer: tspReq,
      nonce: rawNonce,
      nonceDer: nonceDer,
      expectedHash: hashBuffer
    };
  }

  parseStrictTSTInfo(tstInfoBuf) {
    const root = parseTLV(tstInfoBuf, 0);
    if (!root || root.tag !== 0x30) {
      throw new Error('[TSA SCHEMA ERROR]: TSTInfo không phải là ASN.1 SEQUENCE');
    }
    if (root.next !== tstInfoBuf.length) {
      throw new Error('[TSA SCHEMA ERROR]: TSTInfo chứa dữ liệu thừa ở cuối (trailing bytes)');
    }

    let p = 0;
    // 1. Version: INTEGER (bắt buộc v1 = 1)
    const ver = parseTLV(root.val, p);
    if (!ver || ver.tag !== 0x02 || ver.val[0] !== 1) {
      throw new Error('[TSA SCHEMA ERROR]: TSTInfo version không phải là INTEGER 1 (RFC 3161)');
    }
    p = ver.next;

    // 2. Policy: TSAPolicyId (OID)
    const policy = parseTLV(root.val, p);
    if (!policy || policy.tag !== 0x06) throw new Error('[TSA SCHEMA ERROR]: TSTInfo thiếu trường policy (OID)');
    p = policy.next;

    // 3. MessageImprint: SEQUENCE { hashAlgorithm, hashedMessage }
    const imprint = parseTLV(root.val, p);
    if (!imprint || imprint.tag !== 0x30) throw new Error('[TSA SCHEMA ERROR]: TSTInfo thiếu trường messageImprint (SEQUENCE)');
    p = imprint.next;

    const algId = parseTLV(imprint.val, 0);
    if (!algId || algId.tag !== 0x30) throw new Error('[TSA SCHEMA ERROR]: MessageImprint thiếu hashAlgorithm');
    const algOid = parseTLV(algId.val, 0);
    if (!algOid || algOid.tag !== 0x06 || algOid.val.toString('hex') !== '608648016503040201') {
      throw new Error('[TSA SCHEMA ERROR]: Thuật toán băm trong MessageImprint không phải SHA-256');
    }

    const hashOctet = parseTLV(imprint.val, algId.next);
    if (!hashOctet || hashOctet.tag !== 0x04 || hashOctet.val.length !== 32) {
      throw new Error('[TSA SCHEMA ERROR]: MessageImprint không chứa OCTET STRING 32 bytes');
    }
    const hashedMessage = hashOctet.val;

    // 4. SerialNumber: INTEGER (bắt buộc số nguyên dương, kiểm tra canonical DER)
    const sn = parseTLV(root.val, p);
    if (!sn || sn.tag !== 0x02 || sn.val.length === 0) {
      throw new Error('[TSA SCHEMA ERROR]: TSTInfo thiếu trường serialNumber (INTEGER)');
    }
    if ((sn.val[0] & 0x80) !== 0) {
      throw new Error('[TSA SCHEMA ERROR]: serialNumber là số nguyên âm (vi phạm RFC 3161/RFC 5280)');
    }
    if (sn.val.length === 1 && sn.val[0] === 0) {
      throw new Error('[TSA SCHEMA ERROR]: serialNumber có giá trị 0 (phải là số nguyên dương RFC 5280)');
    }
    if (sn.val.length > 1 && sn.val[0] === 0x00 && (sn.val[1] & 0x80) === 0) {
      throw new Error('[TSA SCHEMA ERROR]: serialNumber không tuân thủ DER canonical INTEGER (leading zero thừa)');
    }
    p = sn.next;

    // 5. GenTime: GeneralizedTime (tag 0x18)
    const genTime = parseTLV(root.val, p);
    if (!genTime || genTime.tag !== 0x18) throw new Error('[TSA SCHEMA ERROR]: TSTInfo thiếu trường genTime (GeneralizedTime)');
    const genTimeString = genTime.val.toString('ascii');
    if (!/^\d{14}(\.\d+)?Z$/.test(genTimeString)) {
      throw new Error('[TSA SCHEMA ERROR]: Định dạng GeneralizedTime trong TSTInfo không hợp lệ: ' + genTimeString);
    }
    p = genTime.next;

    // 6. accuracy: Accuracy OPTIONAL (SEQUENCE tag 0x30)
    let accuracy = null;
    if (p < root.val.length) {
      const nextTLV = parseTLV(root.val, p);
      if (!nextTLV) throw new Error('[TSA SCHEMA ERROR]: Phần tử sau genTime không hợp lệ');
      if (nextTLV.tag === 0x30) {
        let accP = 0;
        let hasSec = false, hasMilli = false, hasMicro = false;
        while (accP < nextTLV.val.length) {
          const accField = parseTLV(nextTLV.val, accP);
          if (!accField) throw new Error('[TSA SCHEMA ERROR]: Accuracy SEQUENCE chứa phần tử không hợp lệ');
          if (accField.tag === 0x02 && !hasSec && !hasMilli && !hasMicro) {
            hasSec = true;
          } else if (accField.tag === 0x80 && !hasMilli && !hasMicro) {
            hasMilli = true;
          } else if (accField.tag === 0x81 && !hasMicro) {
            hasMicro = true;
          } else {
            throw new Error('[TSA SCHEMA ERROR]: Accuracy SEQUENCE chứa trường sai quy chuẩn RFC 3161');
          }
          accP = accField.next;
        }
        accuracy = nextTLV.val;
        p = nextTLV.next;
      }
    }

    // 7. ordering: BOOLEAN DEFAULT FALSE (tag 0x01, len 1)
    let ordering = false;
    if (p < root.val.length) {
      const nextTLV = parseTLV(root.val, p);
      if (!nextTLV) throw new Error('[TSA SCHEMA ERROR]: Phần tử sau accuracy không hợp lệ');
      if (nextTLV.tag === 0x01) {
        if (nextTLV.val.length !== 1) throw new Error('[TSA SCHEMA ERROR]: ordering BOOLEAN có độ dài khác 1');
        if (nextTLV.val[0] !== 0x00 && nextTLV.val[0] !== 0xff) {
          throw new Error('[TSA SCHEMA ERROR]: ordering BOOLEAN không tuân thủ DER (phải là 0x00 hoặc 0xFF)');
        }
        ordering = nextTLV.val[0] !== 0x00;
        p = nextTLV.next;
      }
    }

    // 8. nonce: INTEGER OPTIONAL (tag 0x02, bắt buộc số nguyên không âm)
    let nonceVal = null;
    if (p < root.val.length) {
      const nextTLV = parseTLV(root.val, p);
      if (!nextTLV) throw new Error('[TSA SCHEMA ERROR]: Phần tử sau ordering không hợp lệ');
      if (nextTLV.tag === 0x02) {
        if (nextTLV.val.length === 0) throw new Error('[TSA SCHEMA ERROR]: nonce INTEGER rỗng');
        if ((nextTLV.val[0] & 0x80) !== 0) {
          throw new Error('[TSA SCHEMA ERROR]: nonce là số nguyên âm (vi phạm RFC 3161)');
        }
        if (nextTLV.val.length > 1 && nextTLV.val[0] === 0x00 && (nextTLV.val[1] & 0x80) === 0) {
          throw new Error('[TSA SCHEMA ERROR]: nonce INTEGER có leading zero không canonical');
        }
        nonceVal = nextTLV.val;
        p = nextTLV.next;
      }
    }

    // 9. tsa: [0] GeneralName OPTIONAL (tag 0xa0)
    let tsaName = null;
    if (p < root.val.length) {
      const nextTLV = parseTLV(root.val, p);
      if (!nextTLV) throw new Error('[TSA SCHEMA ERROR]: Phần tử sau nonce không hợp lệ');
      if (nextTLV.tag === 0xa0) {
        tsaName = nextTLV.val;
        p = nextTLV.next;
      }
    }

    // 10. extensions: [1] IMPLICIT Extensions OPTIONAL (tag 0xa1)
    let extensions = null;
    if (p < root.val.length) {
      const nextTLV = parseTLV(root.val, p);
      if (!nextTLV) throw new Error('[TSA SCHEMA ERROR]: Phần tử sau tsa không hợp lệ');
      if (nextTLV.tag === 0xa1) {
        extensions = nextTLV.val;
        p = nextTLV.next;
      }
    }

    // Cuối cùng: Tiêu thụ trọn vẹn toàn bộ container TSTInfo
    if (p !== root.val.length) {
      throw new Error(`[TSA SCHEMA ERROR]: TSTInfo SEQUENCE chứa dữ liệu thừa (${root.val.length - p} bytes) hoặc trường sai thứ tự RFC 3161 (Fail-Closed)`);
    }

    return {
      version: ver.val[0],
      policyOid: policy.val.toString('hex'),
      hashedMessage: hashedMessage,
      serialNumber: sn.val.toString('hex'),
      genTime: genTimeString,
      nonce: nonceVal,
      accuracy: accuracy,
      ordering: ordering,
      tsaName: tsaName,
      rawDer: tstInfoBuf
    };
  }

  parseTimeStampResp(respBuffer, expectedNonce, expectedHash, referenceTime = null) {
    if (!Buffer.isBuffer(respBuffer) || respBuffer.length < 32) {
      throw new Error('[TSA FAIL-CLOSED]: Dữ liệu phản hồi TSA quá ngắn hoặc không hợp lệ.');
    }

    const root = parseTLV(respBuffer, 0);
    if (!root || root.tag !== 0x30 || root.next !== respBuffer.length) {
      throw new Error('[TSA FAIL-CLOSED]: Phản hồi không bắt đầu bằng ASN.1 SEQUENCE hoặc chứa dữ liệu thừa ngoài SEQUENCE (0x30).');
    }

    // 1. Phân tích PKIStatusInfo
    const statusTLV = parseTLV(respBuffer, root.pos + root.hl);
    if (!statusTLV || statusTLV.tag !== 0x30) {
      throw new Error('[TSA FAIL-CLOSED]: Cấu trúc PKIStatusInfo không hợp lệ.');
    }

    const statusValTLV = parseTLV(statusTLV.val, 0);
    if (!statusValTLV || statusValTLV.tag !== 0x02 || statusValTLV.val.length === 0) {
      throw new Error('[TSA FAIL-CLOSED]: Không tìm thấy trường INTEGER status trong PKIStatusInfo.');
    }
    const statusCode = statusValTLV.val.length === 1 ? statusValTLV.val[0] : statusValTLV.val.readIntBE(0, statusValTLV.val.length);

    // Tiêu thụ hết PKIStatusInfo container (tránh trailing bytes trong PKIStatusInfo)
    let psiP = statusValTLV.next;
    while (psiP < statusTLV.val.length) {
      const extraTLV = parseTLV(statusTLV.val, psiP);
      if (!extraTLV) {
        throw new Error('[TSA FAIL-CLOSED]: PKIStatusInfo chứa dữ liệu mở rộng không hợp lệ hoặc trailing bytes');
      }
      psiP = extraTLV.next;
    }
    if (psiP !== statusTLV.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: PKIStatusInfo chứa dữ liệu thừa chưa được tiêu thụ');
    }

    if (statusCode !== 0 && statusCode !== 1) {
      throw new Error(`[TSA FAIL-CLOSED]: Máy chủ TSA từ chối cấp dấu thời gian với mã trạng thái: ${statusCode} (RFC 3161 PKIStatus)`);
    }

    // 2. Trích xuất TimeStampToken (ContentInfo)
    const tokenTLV = parseTLV(respBuffer, statusTLV.next);
    if (!tokenTLV || tokenTLV.tag !== 0x30) {
      throw new Error('[TSA FAIL-CLOSED]: Phản hồi TSA thành công nhưng thiếu khối TimeStampToken.');
    }
    if (tokenTLV.next !== root.pos + root.hl + root.len) {
      throw new Error('[TSA FAIL-CLOSED]: TimeStampResp chứa dữ liệu thừa sau TimeStampToken.');
    }

    const timeStampToken = respBuffer.subarray(tokenTLV.pos, tokenTLV.next);

    // 3. Giải mã cấu trúc CMS SignedData bên trong TimeStampToken
    let p = tokenTLV.pos + tokenTLV.hl;
    const ctOid = parseTLV(respBuffer, p);
    if (!ctOid || ctOid.tag !== 0x06 || ctOid.val.toString('hex') !== '2a864886f70d010702') {
      throw new Error('[TSA FAIL-CLOSED]: TimeStampToken không phải là CMS SignedData (OID 1.2.840.113549.1.7.2).');
    }

    const sdCtx = parseTLV(respBuffer, ctOid.next);
    if (!sdCtx || (sdCtx.tag !== 0xa0 && (sdCtx.tag & 0xc0) !== 0x80)) {
      throw new Error('[TSA FAIL-CLOSED]: Thiếu container content [0] của SignedData trong TimeStampToken.');
    }
    if (sdCtx.next !== tokenTLV.next) {
      throw new Error('[TSA FAIL-CLOSED]: TimeStampToken chứa dữ liệu thừa ngoài SignedData container.');
    }

    const sdSeq = parseTLV(sdCtx.val, 0);
    if (!sdSeq || sdSeq.tag !== 0x30 || sdSeq.next !== sdCtx.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: Cấu trúc SignedData SEQUENCE không hợp lệ hoặc chứa trailing bytes.');
    }

    let sP = 0;
    const ver = parseTLV(sdSeq.val, sP); if (!ver || ver.tag !== 0x02) throw new Error('[TSA FAIL-CLOSED]: Thiếu version trong SignedData.'); sP = ver.next;
    const da = parseTLV(sdSeq.val, sP); if (!da || da.tag !== 0x31) throw new Error('[TSA FAIL-CLOSED]: Thiếu digestAlgorithms trong SignedData.'); sP = da.next;
    
    // Đối soát digestAlgorithms trong SignedData: Bắt buộc không rỗng và phải là SHA-256
    if (da.val.length === 0) throw new Error('[TSA FAIL-CLOSED]: SignedData.digestAlgorithms rỗng!');
    const daAlgTLV = parseTLV(da.val, 0);
    if (!daAlgTLV || daAlgTLV.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: AlgorithmIdentifier trong digestAlgorithms không hợp lệ');
    const daAlgOid = parseTLV(daAlgTLV.val, 0);
    if (!daAlgOid || daAlgOid.tag !== 0x06 || daAlgOid.val.toString('hex') !== '608648016503040201') {
      throw new Error('[TSA FAIL-CLOSED]: SignedData.digestAlgorithms OID không phải là SHA-256 (OID 2.16.840.1.101.3.4.2.1)');
    }
    if (daAlgTLV.next !== da.val.length) throw new Error('[TSA FAIL-CLOSED]: digestAlgorithms SET chứa dữ liệu thừa');

    const eci = parseTLV(sdSeq.val, sP); if (!eci || eci.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: Thiếu encapContentInfo trong SignedData.'); sP = eci.next;
    const certsPart = parseTLV(sdSeq.val, sP); if (!certsPart || certsPart.tag !== 0xa0) throw new Error('[TSA FAIL-CLOSED]: Thiếu certificates trong SignedData.'); sP = certsPart.next;
    const sisPart = parseTLV(sdSeq.val, sP); if (!sisPart || sisPart.tag !== 0x31) throw new Error('[TSA FAIL-CLOSED]: Thiếu signerInfos trong SignedData.'); sP = sisPart.next;
    if (sP !== sdSeq.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: SignedData SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes).');
    }

    if (!eci || eci.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: Thiếu encapContentInfo trong SignedData.');
    const eciOid = parseTLV(eci.val, 0);
    if (!eciOid || eciOid.val.toString('hex') !== '2a864886f70d0109100104') {
      throw new Error('[TSA FAIL-CLOSED]: eContentType không phải là id-ct-TSTInfo (OID 1.2.840.113549.1.9.16.1.4).');
    }

    const eContentCtx = parseTLV(eci.val, eciOid.next);
    if (!eContentCtx || eContentCtx.tag !== 0xa0) throw new Error('[TSA FAIL-CLOSED]: Thiếu eContent [0] bên trong encapContentInfo.');
    const eContentOctet = parseTLV(eContentCtx.val, 0);
    if (!eContentOctet || eContentOctet.tag !== 0x04 || eContentOctet.next !== eContentCtx.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: eContent OCTET STRING không hợp lệ hoặc chứa trailing bytes.');
    }

    const tstInfoDer = eContentOctet.val;
    const expectedTstInfoHash = crypto.createHash('sha256').update(tstInfoDer).digest();

    // 4. Phân tích TSTInfo nghiêm ngặt theo schema RFC 3161
    const tstInfo = this.parseStrictTSTInfo(tstInfoDer);

    // 4.1 FAIL-CLOSED: Kiểm tra sai lệch đồng hồ HAI CHIỀU (chống cả future timestamp và stale token replay)
    const tokenDate = new Date(Date.UTC(
      parseInt(tstInfo.genTime.slice(0, 4), 10),
      parseInt(tstInfo.genTime.slice(4, 6), 10) - 1,
      parseInt(tstInfo.genTime.slice(6, 8), 10),
      parseInt(tstInfo.genTime.slice(8, 10), 10),
      parseInt(tstInfo.genTime.slice(10, 12), 10),
      parseInt(tstInfo.genTime.slice(12, 14), 10)
    ));
    const nowMs = referenceTime ? (referenceTime instanceof Date ? referenceTime.getTime() : new Date(referenceTime).getTime()) : Date.now();
    const maxDriftMs = 15 * 60 * 1000; // 15 phút
    if (Math.abs(tokenDate.getTime() - nowMs) > maxDriftMs) {
      if (tokenDate.getTime() > nowMs + maxDriftMs) {
        throw new Error(`[TSA FAIL-CLOSED]: Thời gian cấp dấu trong tương lai vượt quá giới hạn sai lệch cho phép (${tstInfo.genTime} vs hiện tại ${new Date(nowMs).toISOString()})`);
      } else {
        throw new Error(`[TSA FAIL-CLOSED]: Thời gian cấp dấu quá cũ (stale token replay) vượt quá giới hạn sai lệch hai chiều cho phép 15 phút (${tstInfo.genTime} vs hiện tại ${new Date(nowMs).toISOString()})`);
      }
    }

    // 4.2 FAIL-CLOSED: Kiểm tra Policy OID nếu được cấu hình
    if (this.allowedPolicies && Array.isArray(this.allowedPolicies) && this.allowedPolicies.length > 0) {
      if (!this.allowedPolicies.includes(tstInfo.policyOid)) {
        throw new Error(`[TSA FAIL-CLOSED]: Policy OID trong TimeStampToken (${tstInfo.policyOid}) không nằm trong danh mục chính sách được phép!`);
      }
    }

    // 5. FAIL-CLOSED: Kiểm tra bắt buộc Nonce
    if (!expectedNonce) {
      throw new Error('[TSA FAIL-CLOSED]: Thiếu expectedNonce để đối soát phản hồi.');
    }
    if (!tstInfo.nonce) {
      throw new Error('[TSA FAIL-CLOSED]: TimeStampToken không chứa nonce theo yêu cầu RFC 3161!');
    }
    const cleanExpected = expectedNonce[0] === 0 ? expectedNonce.subarray(1) : expectedNonce;
    const cleanVerified = tstInfo.nonce[0] === 0 ? tstInfo.nonce.subarray(1) : tstInfo.nonce;
    if (!cleanExpected.equals(cleanVerified)) {
      throw new Error(`[TSA FAIL-CLOSED]: Nonce trong TimeStampToken (${cleanVerified.toString('hex')}) không khớp với yêu cầu (${cleanExpected.toString('hex')})!`);
    }

    // 6. FAIL-CLOSED: Kiểm tra bắt buộc MessageImprint
    if (!expectedHash) {
      throw new Error('[TSA FAIL-CLOSED]: Thiếu expectedHash để đối soát phản hồi.');
    }
    if (!tstInfo.hashedMessage) {
      throw new Error('[TSA FAIL-CLOSED]: TimeStampToken không chứa hashedMessage trong messageImprint!');
    }
    if (!expectedHash.equals(tstInfo.hashedMessage)) {
      throw new Error(`[TSA FAIL-CLOSED]: Mã băm trong TimeStampToken (${tstInfo.hashedMessage.toString('hex')}) không khớp với băm đã gửi (${expectedHash.toString('hex')})!`);
    }

    // 7. Xác minh chữ ký số RSA-SHA256 của máy chủ TSA và đối chiếu chứng thư tương ứng (ZERO-FALLBACK)
    let isTsaCryptoSigValid = false;
    let tsaCertSubject = null;
    let tsaCertIssuer = null;

    if (!certsPart || certsPart.tag !== 0xa0) {
      throw new Error('[TSA FAIL-CLOSED]: SignedData không chứa certificates [0]');
    }
    if (!sisPart || sisPart.tag !== 0x31) {
      throw new Error('[TSA FAIL-CLOSED]: SignedData không chứa signerInfos SET');
    }

    const siSeq = parseTLV(sisPart.val, 0);
    if (!siSeq || siSeq.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: SignerInfo rỗng hoặc không phải SEQUENCE');
    if (siSeq.next !== sisPart.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: signerInfos SET chứa dữ liệu thừa hoặc nhiều SignerInfo ngoài quy chuẩn (Fail-Closed)');
    }
    let siP = 0;
    const siVer = parseTLV(siSeq.val, siP); if (!siVer || siVer.tag !== 0x02) throw new Error('[TSA FAIL-CLOSED]: Thiếu version trong SignerInfo'); siP = siVer.next;
    const siSid = parseTLV(siSeq.val, siP); if (!siSid || siSid.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: SignerInfo.sid không phải là IssuerAndSerialNumber (tag 0x30)!'); siP = siSid.next;
    const siDa = parseTLV(siSeq.val, siP); if (!siDa || siDa.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: Thiếu digestAlgorithm trong SignerInfo'); siP = siDa.next;
    const siDaOid = parseTLV(siDa.val, 0);
    if (!siDaOid || siDaOid.tag !== 0x06 || siDaOid.val.toString('hex') !== '608648016503040201') {
      throw new Error('[TSA FAIL-CLOSED]: TSA SignerInfo digestAlgorithm không phải là SHA-256 (OID 2.16.840.1.101.3.4.2.1)');
    }

    const sidIssuer = parseTLV(siSid.val, 0);
    if (!sidIssuer || sidIssuer.tag !== 0x30) {
      throw new Error('[TSA FAIL-CLOSED]: Issuer trong SignerInfo.sid không hợp lệ (không phải SEQUENCE tag 0x30)');
    }
    const sidSerial = parseTLV(siSid.val, sidIssuer.next);
    if (!sidSerial || sidSerial.tag !== 0x02) {
      throw new Error('[TSA FAIL-CLOSED]: Serial trong SignerInfo.sid không hợp lệ (không phải INTEGER tag 0x02)');
    }
    if (sidSerial.next !== siSid.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: SignerInfo.sid chứa trailing bytes');
    }

    const targetIssuerDer = siSid.val.subarray(sidIssuer.pos, sidIssuer.next);
    const targetSerialDer = sidSerial.val;

    const signedAttrsPart = parseTLV(siSeq.val, siP);
    if (!signedAttrsPart || signedAttrsPart.tag !== 0xa0) {
      throw new Error('[TSA FAIL-CLOSED]: TSA SignerInfo thiếu signedAttrs [0]');
    }
    siP = signedAttrsPart.next;
    const sigAlg = parseTLV(siSeq.val, siP);
    if (!sigAlg || sigAlg.tag !== 0x30) throw new Error('[TSA FAIL-CLOSED]: Thiếu signatureAlgorithm trong TSA SignerInfo');
    siP = sigAlg.next;
    const sigVal = parseTLV(siSeq.val, siP);
    if (!sigVal || sigVal.tag !== 0x04) {
      throw new Error('[TSA FAIL-CLOSED]: TSA SignerInfo thiếu signatureValue');
    }
    siP = sigVal.next;
    if (siP < siSeq.val.length) {
      const tsaUnsignedAttrs = parseTLV(siSeq.val, siP);
      if (!tsaUnsignedAttrs) throw new Error('[TSA FAIL-CLOSED]: TSA unsignedAttrs không hợp lệ');
      siP = tsaUnsignedAttrs.next;
    }
    if (siP !== siSeq.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: TSA SignerInfo SEQUENCE chứa dữ liệu thừa ở cuối (trailing bytes)');
    }

    // 7.1 Kiểm tra signatureAlgorithm phải là sha256WithRSAEncryption (OID 1.2.840.113549.1.1.11)
    const sigAlgOid = parseTLV(sigAlg.val, 0);
    if (!sigAlgOid || sigAlgOid.tag !== 0x06 || sigAlgOid.val.toString('hex') !== '2a864886f70d01010b') {
      throw new Error('[TSA FAIL-CLOSED]: Thuật toán chữ ký TSA không phải là sha256WithRSAEncryption (OID 1.2.840.113549.1.1.11)');
    }

    // 7.2 Kiểm tra signedAttrs của TSA: messageDigest === SHA256(TSTInfo) và contentType === id-ct-TSTInfo (Chống Duplicate Attributes)
    let saP = 0;
    let tsaEmbeddedMessageDigest = null;
    let tsaEmbeddedContentType = null;
    const seenAttrs = new Set();
    while (saP < signedAttrsPart.val.length) {
      const attr = parseTLV(signedAttrsPart.val, saP);
      if (!attr || attr.tag !== 0x30) {
        throw new Error('[TSA FAIL-CLOSED]: Cấu trúc thuộc tính trong TSA signedAttrs không hợp lệ (Fail-Closed)');
      }
      const aOid = parseTLV(attr.val, 0);
      if (!aOid || aOid.tag !== 0x06) {
        throw new Error('[TSA FAIL-CLOSED]: Thuộc tính TSA signedAttrs thiếu OID hợp lệ');
      }
      const oidHex = aOid.val.toString('hex');
      if (seenAttrs.has(oidHex)) {
        throw new Error(`[TSA FAIL-CLOSED]: Phát hiện thuộc tính trùng lặp trong TSA signedAttrs (OID ${oidHex}) - Fail-Closed`);
      }
      seenAttrs.add(oidHex);

      const aSet = parseTLV(attr.val, aOid.next);
      if (!aSet || aSet.tag !== 0x31 || aSet.next !== attr.val.length) {
        throw new Error('[TSA FAIL-CLOSED]: Thuộc tính signedAttrs phải là SET có độ dài chính xác');
      }
      if (oidHex === '2a864886f70d010904') {
        const oct = parseTLV(aSet.val, 0);
        if (!oct || oct.tag !== 0x04 || oct.next !== aSet.val.length) {
          throw new Error('[TSA FAIL-CLOSED]: messageDigest trong signedAttrs không hợp lệ');
        }
        tsaEmbeddedMessageDigest = oct.val;
      } else if (oidHex === '2a864886f70d010903') {
        const coid = parseTLV(aSet.val, 0);
        if (!coid || coid.tag !== 0x06 || coid.next !== aSet.val.length) {
          throw new Error('[TSA FAIL-CLOSED]: contentType trong signedAttrs không hợp lệ');
        }
        tsaEmbeddedContentType = coid.val.toString('hex');
      }
      saP = attr.next;
    }

    if (!tsaEmbeddedContentType || tsaEmbeddedContentType !== '2a864886f70d0109100104') {
      throw new Error('[TSA FAIL-CLOSED]: TSA signedAttrs contentType không phải là id-ct-TSTInfo!');
    }
    if (!tsaEmbeddedMessageDigest || !expectedTstInfoHash.equals(tsaEmbeddedMessageDigest)) {
      throw new Error('[TSA FAIL-CLOSED]: TSA signedAttrs messageDigest không khớp với mã băm của TSTInfo!');
    }

    // 7.3 Trích xuất toàn bộ chuỗi chứng thư và xác minh Cryptographic Chain of Trust
    let matchedTsaCertDer = null;
    let matchedTsaCount = 0;
    const allCerts = [];
    let cP = 0;
    while (cP < certsPart.val.length) {
      const cTLV = parseTLV(certsPart.val, cP);
      if (!cTLV || cTLV.tag !== 0x30) {
        throw new Error('[TSA FAIL-CLOSED]: Cấu trúc chứng thư không hợp lệ trong certificates container (Fail-Closed)');
      }
      const cDer = certsPart.val.subarray(cTLV.pos, cTLV.next);
      const meta = extractIssuerAndSerialFromCert(cDer);
      if (meta && meta.issuerDer.equals(targetIssuerDer) && meta.serialDer.equals(targetSerialDer)) {
        matchedTsaCertDer = cDer;
        matchedTsaCount++;
      }
      allCerts.push(new crypto.X509Certificate(cDer));
      cP = cTLV.next;
    }
    if (cP !== certsPart.val.length) {
      throw new Error('[TSA FAIL-CLOSED]: certificates container chứa trailing bytes chưa được tiêu thụ');
    }

    if (matchedTsaCount > 1) {
      throw new Error('[TSA FAIL-CLOSED]: Phát hiện nhiều chứng thư trùng khớp SignerInfo.sid (Multiple certificates match SignerInfo.sid)');
    }
    if (!matchedTsaCertDer || matchedTsaCount === 0) {
      throw new Error('[TSA FAIL-CLOSED]: Không tìm thấy chứng thư TSA khớp với IssuerAndSerialNumber trong SignerInfo.sid!');
    }

    const tsaX509 = new crypto.X509Certificate(matchedTsaCertDer);
    tsaCertSubject = tsaX509.subject;
    tsaCertIssuer = tsaX509.issuer;

    // 7.4 Kiểm tra BasicConstraints và Extended Key Usage của Leaf TSA
    if (tsaX509.ca === true) {
      throw new Error('[TSA FAIL-CLOSED]: Chứng thư TSA là chứng thư CA (vi phạm nguyên tắc Leaf TSA)');
    }
    if (!hasTimeStampingEKU(tsaX509)) {
      throw new Error('[TSA FAIL-CLOSED]: Chứng thư TSA thiếu ExtendedKeyUsage id-kp-timeStamping (1.3.6.1.5.5.7.3.8) theo RFC 3161!');
    }

    // 7.5 Xây dựng và xác minh toàn vẹn chuỗi chứng thư X.509 Path Validation (RFC 5280)
    const OFFICIAL_ROOT_CA_G2_FINGERPRINT = 'F0:4B:A4:B4:59:A7:C9:A1:B9:71:AD:9B:1C:B8:33:E6:95:A8:0C:79:AE:A6:3B:17:4B:66:A7:0E:DF:E2:FD:B8';
    const pathValidation = validateX509CertificatePath(tsaX509, allCerts, OFFICIAL_ROOT_CA_G2_FINGERPRINT);
    if (!pathValidation.isValid) {
      throw new Error('[TSA FAIL-CLOSED]: ' + pathValidation.reason);
    }
    const rootCaX509 = pathValidation.rootCa;

    // 7.6 Xác minh vân tay SHA-256 của Leaf TSA (Trust Anchor Pinning)
    const isPinned = this.pinnedFingerprints.has(tsaX509.fingerprint256);
    if (this.enforceTsaPinning && !isPinned) {
      throw new Error(`[TSA FAIL-CLOSED]: Chứng thư TSA không khớp vân tay SHA-256 được ghim cứng của Ban Cơ yếu Chính phủ (Nhận: ${tsaX509.fingerprint256}, Yêu cầu một trong: ${Array.from(this.pinnedFingerprints).join(', ')})`);
    }

    // 7.6 Kiểm tra thời hạn hiệu lực của cả Leaf và RootCA
    const now = new Date();
    const leafFrom = new Date(tsaX509.validFrom);
    const leafTo = new Date(tsaX509.validTo);
    const rootFrom = new Date(rootCaX509.validFrom);
    const rootTo = new Date(rootCaX509.validTo);
    if (now < leafFrom || now > leafTo || Number.isNaN(leafFrom.getTime()) || Number.isNaN(leafTo.getTime())) {
      throw new Error(`[TSA FAIL-CLOSED]: Chứng thư TSA đã hết hạn hoặc thời hạn không hợp lệ (${tsaX509.validFrom} - ${tsaX509.validTo})!`);
    }
    if (now < rootFrom || now > rootTo || Number.isNaN(rootFrom.getTime()) || Number.isNaN(rootTo.getTime())) {
      throw new Error(`[TSA FAIL-CLOSED]: RootCA chuyên dùng Chính phủ đã hết hạn (${rootCaX509.validFrom} - ${rootCaX509.validTo})!`);
    }

    // 7.6 Xác thực chữ ký số RSA-SHA256 trên signedAttrs SET
    const signedAttrsSet = Buffer.concat([
      Buffer.from([0x31]),
      encodeLength(signedAttrsPart.val.length),
      signedAttrsPart.val
    ]);

    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(signedAttrsSet);
    verifier.end();
    isTsaCryptoSigValid = verifier.verify(tsaX509.publicKey, sigVal.val);

    if (!isTsaCryptoSigValid) {
      throw new Error('[TSA FAIL-CLOSED]: Chữ ký số mật mã RSA của máy chủ TSA không hợp lệ!');
    }

    return {
      statusCode: statusCode,
      statusDesc: statusCode === 0 ? 'GRANTED' : 'GRANTED_WITH_MODS',
      timeStampToken: timeStampToken,
      genTime: tstInfo.genTime,
      serialNumber: tstInfo.serialNumber,
      verifiedNonce: cleanVerified.toString('hex'),
      verifiedImprint: tstInfo.hashedMessage.toString('hex'),
      tsaCertSubject: tsaCertSubject,
      tsaCertIssuer: tsaCertIssuer,
      tsaCertFingerprint: tsaX509.fingerprint256,
      tsaTrustModel: {
        level: 'VGCA_PINNED_TRUST_ANCHOR',
        trustAnchor: 'RootCA chuyên dùng Chính phủ G2 (Ban Cơ yếu Chính phủ)',
        fingerprint: tsaX509.fingerprint256,
        rootCaFingerprint: rootCaX509.fingerprint256,
        isPinned: isPinned,
        isGovRootCa: true,
        revocationStatus: 'DEFERRED_TO_PHASE3_GATEWAY'
      },
      isTsaCryptoSigValid: isTsaCryptoSigValid,
      rawResp: respBuffer
    };
  }

  async requestTimestamp(hashBuffer) {
    const { tspReqBuffer, nonce, expectedHash } = this.buildTimeStampReq(hashBuffer);
    const url = new URL(this.tsaUrl);
    const isHttps = url.protocol === 'https:';
    const transport = isHttps ? https : http;

    let lastError = null;
    for (let attempt = 1; attempt <= this.maxRetries + 1; attempt++) {
      try {
        const respBuf = await this._sendHttpRequest(transport, url, isHttps, tspReqBuffer);
        const parsed = this.parseTimeStampResp(respBuf, nonce, expectedHash);
        return parsed;
      } catch (err) {
        lastError = err;
        console.warn(`[TSA ATTEMPT ${attempt} FAILED]: ${err.message}`);
        if (err.message.includes('FAIL-CLOSED')) {
          throw err;
        }
        if (attempt <= this.maxRetries) {
          const delay = this.retryDelayMs * Math.pow(2, attempt - 1);
          await new Promise(r => setTimeout(r, delay));
        }
      }
    }

    if (this.allowMockFallback) {
      console.warn('[TSA FALLBACK]: Kích hoạt Dấu thời gian mô phỏng nội bộ do máy chủ TSA chính thức không phản hồi.');
      return this._generateMockTimestampToken(hashBuffer, nonce);
    }

    throw new Error(`[TSA CRITICAL ERROR]: Không thể kết nối tới máy chủ Dấu thời gian Ban Cơ yếu Chính phủ (${this.tsaUrl}) sau ${this.maxRetries + 1} lần thử: ${lastError.message}`);
  }

  _sendHttpRequest(transport, url, isHttps, tspReqBuffer) {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: url.hostname,
        port: url.port || (isHttps ? 443 : 80),
        path: url.pathname + url.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/timestamp-query',
          'Accept': 'application/timestamp-reply',
          'User-Agent': 'VGCASignTool-WebSigner/2.0',
          'Content-Length': tspReqBuffer.length
        },
        timeout: this.timeoutMs
      };

      const req = transport.request(options, (res) => {
        const chunks = [];
        res.on('data', chunk => chunks.push(chunk));
        res.on('end', () => {
          const respBuf = Buffer.concat(chunks);
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode} ${res.statusMessage} - ${respBuf.toString('utf8').substring(0, 150)}`));
            return;
          }
          const ctype = (res.headers['content-type'] || '').toLowerCase();
          if (!ctype.includes('timestamp-reply')) {
            reject(new Error(`Content-Type không phải 'application/timestamp-reply' (Nhận: ${ctype})`));
            return;
          }
          resolve(respBuf);
        });
      });

      req.on('error', err => reject(err));
      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`Timeout sau ${this.timeoutMs}ms`));
      });

      req.write(tspReqBuffer);
      req.end();
    });
  }

  _generateMockTimestampToken(hashBuffer, nonce) {
    const pad = n => String(n).padStart(2, '0');
    const d = new Date();
    const genTimeStr = `${d.getUTCFullYear()}${pad(d.getUTCMonth()+1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
    
    const ver = Buffer.from([0x02, 0x01, 0x01]);
    const policy = Buffer.from([0x06, 0x07, 0x60, 0x85, 0x40, 0x01, 0x01, 0x01, 0x02]);
    const sha256AlgId = Buffer.from([0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00]);
    const octet = Buffer.concat([Buffer.from([0x04, 0x20]), hashBuffer]);
    const imprint = Buffer.concat([Buffer.from([0x30, 0x31]), sha256AlgId, octet]);
    const sn = Buffer.from([0x02, 0x08, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]);
    const genTime = Buffer.concat([Buffer.from([0x18, genTimeStr.length]), Buffer.from(genTimeStr, 'ascii')]);
    const nonceDer = encodeCanonicalInteger(nonce);

    const tstBody = Buffer.concat([ver, policy, imprint, sn, genTime, nonceDer]);
    const tstInfo = Buffer.concat([Buffer.from([0x30, tstBody.length]), tstBody]);
    const eContent = Buffer.concat([Buffer.from([0x04, tstInfo.length]), tstInfo]);
    const eciBody = Buffer.concat([
      Buffer.from([0x06, 0x0b, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x09, 0x10, 0x01, 0x04]),
      Buffer.concat([Buffer.from([0xa0, eContent.length]), eContent])
    ]);
    const encapContentInfo = Buffer.concat([Buffer.from([0x30, eciBody.length]), eciBody]);

    const dummyCmsBody = Buffer.concat([
      Buffer.from([0x02, 0x01, 0x03]),
      Buffer.from([0x31, 0x0f, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00]),
      encapContentInfo,
      Buffer.from([0x31, 0x00])
    ]);
    const signedDataSeq = Buffer.concat([Buffer.from([0x30, 0x82, (dummyCmsBody.length >> 8) & 0xff, dummyCmsBody.length & 0xff]), dummyCmsBody]);
    const contentInfoBody = Buffer.concat([
      Buffer.from([0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x02]),
      Buffer.concat([Buffer.from([0xa0, 0x82, (signedDataSeq.length >> 8) & 0xff, signedDataSeq.length & 0xff]), signedDataSeq])
    ]);
    const timeStampToken = Buffer.concat([Buffer.from([0x30, 0x82, (contentInfoBody.length >> 8) & 0xff, contentInfoBody.length & 0xff]), contentInfoBody]);

    if (process.env.NODE_ENV === 'production') {
      throw new Error('[TSA CRITICAL]: Mock fallback bị vô hiệu hóa tuyệt đối trong môi trường sản xuất (NODE_ENV=production)');
    }

    return {
      statusCode: 0,
      statusDesc: 'MOCK_NON_COMPLIANT_LOCAL_TEST_ONLY',
      isMock: true,
      timeStampToken: timeStampToken,
      genTime: genTimeStr,
      verifiedNonce: nonce.toString('hex'),
      verifiedImprint: hashBuffer.toString('hex'),
      isTsaCryptoSigValid: false // Mock token hoàn toàn KHÔNG có chữ ký mật mã TSA
    };
  }
}

module.exports = TsaClient;
module.exports.TsaClient = TsaClient;
module.exports.extractIssuerAndSerialFromCert = extractIssuerAndSerialFromCert;
module.exports.parseTLV = parseTLV;
module.exports.encodeLength = encodeLength;
module.exports.encodeTLV = encodeTLV;
module.exports.encodeSeq = encodeSeq;
module.exports.encodeSet = encodeSet;
module.exports.encodeOctetString = encodeOctetString;
module.exports.encodeOID = encodeOID;
module.exports.encodeCanonicalInteger = encodeCanonicalInteger;
module.exports.encodeUTCTime = encodeUTCTime;
module.exports.hasTimeStampingEKU = hasTimeStampingEKU;
module.exports.validateX509CertificatePath = validateX509CertificatePath;
module.exports.parseBasicConstraintsFromDer = parseBasicConstraintsFromDer;
module.exports.parseKeyUsageFromDer = parseKeyUsageFromDer;

